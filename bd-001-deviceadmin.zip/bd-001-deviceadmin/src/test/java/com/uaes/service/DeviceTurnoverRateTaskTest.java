package com.uaes.service;

import org.junit.Test;

import static org.junit.Assert.*;

public class DeviceTurnoverRateTaskTest {
    @Test
    public void countDevice() throws Exception {
        DeviceTurnoverRateTask deviceTurnoverRateTask = new DeviceTurnoverRateTask();
        deviceTurnoverRateTask.CountDevice();
    }

}