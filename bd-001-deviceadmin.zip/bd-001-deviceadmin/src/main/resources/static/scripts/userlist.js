
/**
 * @author xu wen feng 8/9/2018 09:18
 */
$(document).ready(function () {
    $.ajax({
        url: "/BD-001-deviceadmin/eswmp/getSections",
        type: "post",
        success: function (data) {
            for (var i = 0; i < data.length; i++) {
                document.getElementById("section").options.add(new Option(data[i], data[i]));
            }
        },
        error: function () {
            alert("error");
        }
    });
})