
/**
 * @author xu wen feng 8/9/2018 09:18
 */
$(document).ready(function () {
    $.ajax({
        url: "/BD-001-deviceadmin/eswmp/getSections",
        type: "post",
        success: function (data) {
            var optionString = "";
            for (var i = 0; i < data.length; i++) {
                optionString += "<option value=\'" + data[i] + "\'>" + data[i] + "</option>";
            }
            $("#section").html(optionString);
            $("#section").selectpicker('refresh');
        },
        error: function () {
            alert("error");
        }
    });

    $.ajax({
        url: "/BD-001-deviceadmin/eswmp/getStatus",
        type: "post",
        success: function (data) {
            var str = '';
            for (var i = 0; i < data.length; i++) {
                if (data[i] == '0') {
                    data[i] = '正常';
                } else if (data[i] == '1') {
                    data[i] = '报修';
                } else if (data[i] == '2') {
                    data[i] = '在修';
                } else if (data[i] == '3'){
                    data[i] = '已损坏';
                }else{
                    data[i] = '已归还';
                }

                //document.getElementById("status").options.add(new Option(str, data[i]));
                str += "<option value=\'" + data[i] + "\'>" + data[i] + "</option>";
            }
            $("#status").html(str);
            $("#status").selectpicker('refresh');
        },
        error: function () {
            alert("error");
        }
    });
    /*console.info("--->" + $("#sections").val());
    var sections = $("#sections").val();
    var arr = sections.split(",");
    var selectObj = $("#section");
    for (var i = 0; i < arr.length; i++) {
        for (var m = 0; m < selectObj.length; m++) {
            if (selectObj.options[m].text == arr[i]) {
                selectObj[m].selected = true;
            }
        }
    }*/
})