// $('#adminplatform').on('click',function(){
//           alert("test");
//           })


//$("#adminplatform").children("li").click(function(e){
//    alert("test");
//    return false;
//});
