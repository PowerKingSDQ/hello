/**
 * Created by Administrator on 2017/2/14.
 */
$(document).ready(function () {
    //    alert("OK TEST");
    $.ajax({
        type: 'get',
        url: '/BD-001-deviceadmin/eswmp/alloperating',
        data: {},
        beforeSend: function (XMLHttpRequest) {

        },
        success: function (data, status) {
            //            alert("msg: " + data[0].eid);
            for (var i in data) {
                $('#table').append("<tr><td>" + data[i].sn +
                    "</td><td>" + data[i].ne1did +
                    "</td><td>" + data[i].scanner +
                    "</td><td>" + data[i].operatingtype +
                    "</td><td>" + data[i].timestamp +
                    "</td><td>" + data[i].description + "</td></tr>");
            }
            //            $('#table').html("<tr><td>"+data[0].eid+"</td><td>"+data[0].dname+"</td>"</tr>");////////////
        },
        complete: function (XMLHttpRequest, textStatus) {

        },
        error: function () {
            alert("msg: " + 'error');
        }
    });
});
$(function () {
    if ($("#mess").val()) {
        alert($("#mess").val());
        $("#mess").val("");
        history.go(-1);
    }
});
