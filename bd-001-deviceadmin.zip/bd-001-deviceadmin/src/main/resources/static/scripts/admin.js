
$(document).ready(function () {

    $.ajax({
        type: 'get',
        url: '/BD-001-deviceadmin/search/adminlist',
        data: {},
        beforeSend: function (XMLHttpRequest) {

        },
        success: function (data, status) {
            var html = "";
            console.log(data);
            for (var i = 0; i < data.length; i++) {    //遍历data数组
                var ls = data[i];
                //                 html +="<li><a href='second page text.html?newsid="+ls.news_id+"'class='infNews_wrod_a'><span>"+ls.news_name+"</span></a><span class='date'>"+ls.news_time+"</span></li>";
                html += "<li class='list-group-item'>" +
                    "<span class='spn-name'>" + ls.ename + "</span>" +
                    "<span style='margin-left: 100px'>" + ls.ugroup + "</span>" +
                    "<button style='margin-left: 100px' type='submit' class='btn_submit' onclick='clicked(" + ls.sn + ")'>删除</button>" +
                    "</li>";
            }
            $("#adminlist").html(html);
        },
        complete: function (XMLHttpRequest, textStatus) {

        },
        error: function () {
            alert("msg: " + 'error');
        }
    });
});
$(function () {
    if ($("#mess").val()) {
        alert($("#mess").val());
        $("#mess").val("");
        history.go(-1);
    }
});
function clicked(e) {
    var r = confirm("确认删除!");
    if (r == true) {
        $.ajax({
            type: 'get',
            url: '/BD-001-deviceadmin/search/deleteadmin',
            data: { sn: e },
            beforeSend: function (XMLHttpRequest) {

            },
            success: function (data, status) {
                console.log("data=" + data);
                if (data == 1) {
                    location.reload();
                } else {
                    alert("更改失败");
                }
            },
            complete: function (XMLHttpRequest, textStatus) {

            },
            error: function () {
                alert("msg: " + 'error');
            }
        });
    }
    else {

    }


}

//当在搜索框输入内容时，根据关键字匹配，显示弹出层
function searchSuggest(obj) {
    var searchKey = $(obj).val();
    //      var reg = new RegExp(searchKey,"i"); //忽略大小写匹配搜索框中输入的内容
    $.ajax({
        type: "get",
        url: "/BD-001-deviceadmin/search/getuserbykeyword",
        data: { keyword: searchKey },
        success: function (data) {
            var arr = [];
            console.log(data);
            for (var i = 0, len = data.length; i < len; i++) {
                if (searchKey != "" && (data[i].ename != "")) {
                    arr.push("<li onclick='changeSearchKey(this);'>" + data[i].ename + "</li>");
                }
                $(".keywords_list").html(arr).show();
            }
        }
    });
}
//单击匹配列表中的关键字选项时，将该关键字显示在搜索框中
function changeSearchKey(obj) {
    var value = $(obj).text();
    $("#searchKey").val(value);
    $('.keywords_list').hide();
}