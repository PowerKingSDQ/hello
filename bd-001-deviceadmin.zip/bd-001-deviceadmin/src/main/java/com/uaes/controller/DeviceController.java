package com.uaes.controller;

import com.uaes.entity.*;
import com.uaes.repository.*;
import com.uaes.service.DeviceQueryService;
import com.uaes.service.*;
import com.uaes.service.OperatingQueryService;
import com.uaes.service.UserQueryService;
import com.uaes.util.HttpUtils;
import lombok.extern.slf4j.Slf4j;
import net.sf.json.JSONObject;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.*;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

@Slf4j
@Controller
@RequestMapping(path = "/eswmp")
public class DeviceController {
    public static int NE1did = 0;
    private String prCodePath = null;
    private String dPicPath = null;

    @Autowired
    private OperatingPlusSectionRepository operatingPlusSectionRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private DeviceCusRepository deviceCusRepository;
    @Autowired
    private OperatingRepository operatingRepository;
    @Autowired
    private ScanRepository scanRepository;

    @Autowired
    private DeviceQueryService deviceQueryService;

    @Autowired
    private UserQueryService userQueryService;

    @Autowired
    private OperatingQueryService operatingQueryService;

    @Autowired
    private MailService mailService;

    @Autowired
    private GetSelectContentsDao getSelectContentsDao;

    @Value("${defaultCcMailAddr}")
    String defaultCcMailAddr;

    @Value("${server.display-name}")
    String version;

    @GetMapping(path = "/adduser") // Map ONLY GET Requests
    public @ResponseBody
    String addNewUser(@RequestParam String ename,
                      @RequestParam String pwd,
                      @RequestParam String esection,
                      @RequestParam String chineseName) {
        ename = ename.replaceAll(" ", "");
        List<User> userlist = userRepository.findByEname(ename);
        String desc = "认证通过";
        if (userlist.size() != 0) {
            return "already registed";
        } else {
            String strObj = LoginController.getWebServerInfo(ename, pwd);
            JSONObject myJsonObject = JSONObject.fromObject(strObj);
            desc = myJsonObject.getString("desc");
            if (desc.equals("认证通过")) {
                User n = new User();
                n.setEname(ename);
                n.setEsection(esection);
                n.setChinesename(chineseName);
                n.setManager("");
                n.setUgroup("user");
                n.setEmail(ename + "@uaes.com");
                userRepository.save(n);
                return desc;
            } else {
                String mess = "账号或者密码错误";
                return mess;
            }
        }
    }

    @GetMapping(path = "/alldevice")
    public @ResponseBody
    Iterable<Device> getAllDevices() {
        // This returns a JSON or XML with the users
        return deviceCusRepository.findAllBy();
    }

    @GetMapping(path = "/getdevice") // Map ONLY GET Requests
    public @ResponseBody
    Iterable<SnDnameDidEid> getDevice(@RequestParam(value = "page", defaultValue = "0") Integer page,
                                      @RequestParam(value = "size", defaultValue = "15") Integer size) {
        Pageable pageable = new PageRequest(page, size, Sort.Direction.ASC, "sn");
        return deviceCusRepository.findAll(pageable);
    }

    @GetMapping(path = "/getDeviceForWX") // Map ONLY GET Requests
    public @ResponseBody Page<Object[]> getDeviceForWX(@RequestParam(value = "page", defaultValue = "0") Integer page,
                                       @RequestParam(value = "size", defaultValue = "15") Integer size,
                                       @RequestParam(defaultValue = "")String dname,@RequestParam(defaultValue = "") String ne1did,
                                       @RequestParam(defaultValue = "") String section,@RequestParam(defaultValue = "") String name){
        Page<Object[]> p = deviceCusRepository.getAllDeviceForWX(dname,ne1did,section,name,new PageRequest(page, size));
        return p;
    }

    @GetMapping(path = "/alluser")
    public @ResponseBody
    Iterable<User> getAllUsers() {
        return userRepository.findAllBy();
    }

    @GetMapping(path = "/alloperating")
    public @ResponseBody
    Iterable<Operating> getAllOperatings() {
        return operatingRepository.findAllBy();
    }

    @GetMapping(path = "/userdevice")
    public @ResponseBody
    Iterable<DnameAndDid> getUserDevice(@RequestParam String name) {
        System.out.println("..................name = [" + name + "]");

        return deviceCusRepository.findByOwner(name);

    }

    @GetMapping(path = "/repairdevice")
    public @ResponseBody
    String getRepairDevice(@RequestParam String ne1did, @RequestParam String dec) {
        System.out.println("..................ne1did = [" + ne1did + "]" + dec);
        String status = "1";//设备状态0正常；1报修 ；2在修；3已损坏
        String operation = "repair";
        deviceCusRepository.setDeviceStatus(ne1did, status);
        scanRepository.setOperating(operation, dec, ne1did);

        List<Device> listDevice = deviceCusRepository.findByNe1did(ne1did);
        Device device = listDevice.get(0);
        String owner = device.getOwner();
        String section = device.getSection();

        List<User> users = userRepository.findByEname(owner);


        List<User> sectionAdmin = userRepository.findByEsectionAndUgroup(section, "Admin");
        String sectionAdminEmailAddr = null;
        if (sectionAdmin.size() > 0) {
            sectionAdminEmailAddr = sectionAdmin.get(0).getEmail();
        } else {
            sectionAdminEmailAddr = defaultCcMailAddr;
        }

        LocalDateTime today = LocalDateTime.now();
        DateTimeFormatter dfyyymmdd = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        String mailContextFormat = "%s:\n\r" +
                "\n\r" +
                "\t您好！\n\r" +
                "\t您正在使用的设备（ NE1Did:%s） 因为以下原因：\n\r" +
                "\t%s" +
                "\n\r" +
                "\t需要维修！\n\r" +
                "\t谢谢！\n\r" +
                "\n\r" +
                "%s\n\r" +
                "%s\n\r";

//        String userName = sendTo.substring(0, sendTo.indexOf("@"));
        String sendTo = sectionAdminEmailAddr;
        String copyTo = users.get(0).getEmail();
        String mailContent = String.format(mailContextFormat, sendTo, ne1did, dec, owner, today.format(dfyyymmdd));

        String mailObject = String.format("设备保修（%s）", ne1did);


        mailService.sendAndCopySimpleMail(sendTo, copyTo, mailObject, mailContent);


        return "save OK";

    }

    @GetMapping(path="/getdevicesbykeyword")
    public @ResponseBody Iterable<Device> getDevicesBykeyword(@RequestParam String keyword,HttpServletRequest request) {
        // This returns a JSON or XML with the users
//        System.out.println("..................eid = [" + ne1did + "]"+dec);
        Iterable<Device> l = deviceCusRepository.findByNe1didLikeOrNameLikeOrDnameLikeOrSectionLike("%"+keyword+"%","%"+keyword+"%","%"+keyword+"%","%"+keyword+"%");
        return l;
    }

    /**
     * 通过ename获取用户信息，获取权限
     * @param request
     * @return
     */
    @RequestMapping(path = "/getUserAuth")
    public @ResponseBody User getUserByEname(HttpServletRequest request,String ename){
        //String ename = request.getParameter("ename");
        List<User> listUser = userRepository.findByEname(ename);
        return listUser.get(0);
    }

    @RequestMapping("/addDeviceFormp")
    public @ResponseBody String addDevice(HttpServletRequest request, Model model) throws IOException{
        //如果设备已经注册过，用来储存设备曾经的二维码路径
        String qrcodePath = "";
        HttpSession session = request.getSession(true);
        String  username = (String) session.getAttribute("username");
        Device device = new Device();
        System.out.println("..................dname = [" + request.getParameter("dname") + "]"+request.getParameter("description"));
        String dname = request.getParameter("dname");
        //dname = new String(dname.getBytes("iso8859-1"),"utf-8");
        String uaesdid = request.getParameter("uaesdid");
        device.setDname(dname);
        device.setDescription(request.getParameter("description"));
        device.setDid(request.getParameter("did"));
        device.setUaesdid(uaesdid);
        device.setCustodian(request.getParameter("custodian"));
        device.setRemarks(request.getParameter("remarks"));
        device.setSection(request.getParameter("section"));
        device.setName(request.getParameter("custodian"));
        device.setOwner(username);
        device.setStatus("0");
        //处理图片
        device.setDpic(request.getParameter("dpic"));
        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String date = fmt.format(new Date());
        if(!LoginController.isDebug){
            NE1did = LoginController.getNE1DID();
        }
        NE1did ++;
        String ne1did;
        if(0 <= NE1did && NE1did < 10){
            ne1did="NE10000"+String.valueOf(NE1did);
        }else if(10 <= NE1did && NE1did < 100){
            ne1did="NE1000"+String.valueOf(NE1did);
        }else if(100 <= NE1did && NE1did < 1000){
            ne1did="NE100"+String.valueOf(NE1did);
        }else if(1000 <= NE1did && NE1did < 10000){
            ne1did="NE10"+String.valueOf(NE1did);
        }else{
            ne1did="NE1"+String.valueOf(NE1did);
        }
        device.setNe1did(ne1did);
        if (LoginController.isDebug){
            prCodePath = LoginController.domainTest + "static/qrcode/images/" + ne1did + ".png";
        }else{
            prCodePath = LoginController.domain + "static/qrcodeImg/images/" + ne1did + ".png";
        }
        device.setPrcodepath(prCodePath);
        device.setFirstusedate(date);
        if(!LoginController.isDebug){
            LoginController.saveNE1DID(NE1did);
        }
        try {
            //注册之前先用固定资产编号去数据库查询此设备是否已经被注册  uaesdid
            if(uaesdid == "" || uaesdid == null){
                System.out.println("device.getDname()："+device.getDname());
                LoginController.qrcode(device.getDname(), device.getUaesdid(), ne1did, model);
                device = deviceCusRepository.save(device);
                qrcodePath = device.getPrcodepath();
            } else {
                List<Device> list = deviceQueryService.findByUaesDid(uaesdid);
                if(list == null || list.size() == 0) {
                    LoginController.qrcode(device.getDname(), device.getUaesdid(), ne1did, model);
                    device = deviceCusRepository.save(device);
                    qrcodePath = device.getPrcodepath();
                } else {
                    //如果固定资产编号不存在，即此设备没有注册过
                    qrcodePath = list.get(0).getPrcodepath();
                }
            }
//          dname = new String(dname.getBytes("ISO-8859-1"),"UTF-8");
//          //ne1did = new String(ne1did.getBytes("ISO-8859-1"),"UTF-8");
//          String uaesdid = request.getParameter("uaesdid");
            //uaesdid =  new String(uaesdid.getBytes("ISO-8859-1"),"UTF-8");
        }catch (Exception e){
            e.printStackTrace();
            return "";
        }
        return qrcodePath;
    }

    @RequestMapping("/uploadFile")
    public @ResponseBody String uploadPicture(HttpServletRequest request, MultipartHttpServletRequest mRequest) throws Exception {
        //获取文件需要上传到的路径
        String path = null;
        if(LoginController.isDebug){
            path = "d://upload/";
        } else {
            path = "/opt/devicesinfo/deviceImg/";
        }
        String realPath = "";
        File dir = new File(path);
        if (!dir.exists()) {
            dir.mkdir();
        }
        //String uaesDid = request.getParameter("uaesdid");
        //String dname = request.getParameter("dname");
        //String ne1did = request.getParameter("ne1did");
        if(!LoginController.isDebug){
            NE1did = LoginController.getNE1DID();
        }
        NE1did ++;
        String ne1did;
        if(0 <= NE1did && NE1did < 10){
            ne1did="NE10000"+String.valueOf(NE1did);
        }else if(10 <= NE1did && NE1did < 100){
            ne1did="NE1000"+String.valueOf(NE1did);
        }else if(100 <= NE1did && NE1did < 1000){
            ne1did="NE100"+String.valueOf(NE1did);
        }else if(1000 <= NE1did && NE1did < 10000){
            ne1did="NE10"+String.valueOf(NE1did);
        }else{
            ne1did="NE1"+String.valueOf(NE1did);
        }

        MultipartFile mf = mRequest.getFile("file");
        try {
            //自定义上传图片的名字为userId.jpg
            String fileName = ne1did + "upload.png";
            String destPath = path + fileName;
            realPath = destPath;

            //真正写到磁盘上
            File file = new File(destPath);
            OutputStream out = new FileOutputStream(file);
            InputStream in = mf.getInputStream();
            int length = 0;
            byte[] buf = new byte[1024];
            // in.read(buf) 每次读到的数据存放在buf 数组中
            while ((length = in.read(buf)) != -1) {
                //在buf数组中取出数据写到（输出流）磁盘上
                out.write(buf, 0, length);
            }
            in.close();
            out.close();
        }  catch (Exception e) {
            e.printStackTrace();
        }
        return realPath;
    }


    @PostMapping(path = "/adddevice")
    public String addDevice(@RequestParam("file") MultipartFile file, HttpServletRequest request, Model model) throws IOException {
        String username = (String) request.getSession().getAttribute("username");
        Device device = new Device();
        System.out.println("..................dname = [" + request.getParameter("dname") + "]" + request.getParameter("description"));
        String dname = request.getParameter("dname");
        device.setDname(dname);
        device.setDescription(request.getParameter("description"));
        device.setDid(request.getParameter("did"));
        device.setUaesdid(request.getParameter("uaesdid"));
        device.setCustodian(request.getParameter("custodian"));
        device.setRemarks(request.getParameter("remarks"));
        device.setSection(request.getParameter("section"));
        device.setName(request.getParameter("custodian"));
        device.setOwner(username);
        device.setStatus("0");
        model.addAttribute("uaesdid",request.getParameter("uaesdid"));
        if(!LoginController.isDebug){
            NE1did = LoginController.getNE1DID();
        }
        NE1did++;
        String ne1did;
        if (0 <= NE1did && NE1did < 10) {
            ne1did = "NE10000" + String.valueOf(NE1did);
        } else if (10 <= NE1did && NE1did < 100) {
            ne1did = "NE1000" + String.valueOf(NE1did);
        } else if (100 <= NE1did && NE1did < 1000) {
            ne1did = "NE100" + String.valueOf(NE1did);
        } else if (1000 <= NE1did && NE1did < 10000) {
            ne1did = "NE10" + String.valueOf(NE1did);
        } else {
            ne1did = "NE1" + String.valueOf(NE1did);
        }
        device.setNe1did(ne1did);
        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String date = fmt.format(new Date());

        device.setFirstusedate(date);
        try {
            LoginController.qrcode(dname,device.getUaesdid(),ne1did, model);
        } catch (Exception e) {
            e.printStackTrace();
        }
//        if (LoginController.isDebug){
//
//            prCodePath = LoginController.domainTest  + ne1did + ".png";
//        }else{
//            prCodePath = LoginController.domain + "static/" + ne1did + ".png";
//        }
        if (LoginController.isDebug){
            prCodePath = LoginController.domainTest + "static/qrcode/images/" + ne1did + ".png";
        }else{
            prCodePath = LoginController.domain + "static/qrcodeImg/images/" + ne1did + ".png";
        }
        device.setPrcodepath(prCodePath);
        if (!LoginController.isDebug) {
            LoginController.saveNE1DID(NE1did);
        }
//        File savedFile = new File("/var/ftp/pub/ExpZipFtp/", file.getOriginalFilename());
        if (!file.isEmpty()) {
//            File savedFile = new File("E:\\myimgs", file.getOriginalFilename());
            File savedFile = new File("/opt/devicesinfo/deviceImg/", file.getOriginalFilename());
            savedFile.setWritable(true, false);
            savedFile.setReadable(true, false);
            FileUtils.copyInputStreamToFile(file.getInputStream(), savedFile);
            if (LoginController.isDebug) {

                dPicPath = LoginController.domainTest + file.getOriginalFilename();
            } else {
                dPicPath = LoginController.domain + "static/" + file.getOriginalFilename();
            }
            device.setDpic(dPicPath);
        }
        deviceCusRepository.save(device);
        return "qrcode/qrcode";

    }

    @GetMapping(path = "/scan") // Map ONLY GET Requests
    public @ResponseBody
    String scan(@RequestParam String repository,
                @RequestParam String ne1did,
                @RequestParam String scaner,
                @RequestParam String name,
                @RequestParam String section) {
        // @ResponseBody means the returned String is the response, not a view name
        // @RequestParam means it is a parameter from the GET or POST request
        Operating s = new Operating();
        s.setNe1did(ne1did);
        s.setScanner(scaner);
        s.setOperatingtype("scan");
        s.setDescription("");
        //加上科室
        s.setSection(section);
        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String date = fmt.format(new Date());
        s.setTimestamp(date);
        scanRepository.save(s);
        if (repository.equals("device")) {
            System.out.println("repository = [" + repository + "], did = [" + ne1did + "], name = [" + name + "]");
            deviceCusRepository.setDeviceUser(ne1did, scaner, name);
        }
        return "save OK";
    }

    @RequestMapping(value = "/getDeviceByParam", method = {RequestMethod.GET, RequestMethod.POST})
    public @ResponseBody Device getDeviceByParam(HttpServletRequest request, Model model){
        String ne1did = request.getParameter("ne1did");
        List<Device> list = deviceQueryService.getDeviceByParam(ne1did);
        if (list == null || list.size() < 1){
            return null;
        } else {
            return list.get(0);
        }
    }

    @RequestMapping(value = "/findDeviceQuery", method = {RequestMethod.GET, RequestMethod.POST})
    public String findDeviceQuery(HttpServletRequest request, Model model, @RequestParam(value = "page", defaultValue = "0") Integer page,
                                  @RequestParam(value = "size", defaultValue = "15") Integer size,
                                  @RequestParam(defaultValue = "") String sections, DeviceQuery deviceQuery,String status) {
        if (StringUtils.hasLength(sections)) {
            List<String> list = Arrays.asList(sections.split(","));
            deviceQuery.setSections(list);
        }
        if (StringUtils.hasLength(status)) {
            List<String> list1 = Arrays.asList(status.split(","));
            List arrList = new ArrayList(list1);
            for(int i = 0;i < list1.size();i++){
                if (arrList.get(i) == "正常" || "正常".equals(arrList.get(i))){
                    arrList.remove(i);
                    arrList.add(i,"0");
                } else if(arrList.get(i) == "报修" || "报修".equals(arrList.get(i))){
                    arrList.remove(i);
                    arrList.add(i,"1");
                } else if(arrList.get(i) == "在修" || "在修".equals(arrList.get(i))){
                    arrList.remove(i);
                    arrList.add(i,"2");
                } else if(arrList.get(i) == "已损坏" || "已损坏".equals(arrList.get(i))){
                    arrList.remove(i);
                    arrList.add(i,"3");
                } else {
                    arrList.remove(i);
                    arrList.add(i,"4");
                }
            }
            deviceQuery.setStatus(arrList);
        }
        Page<Device> datas = deviceQueryService.findDeviceCriteria(page, size, deviceQuery);
        model.addAttribute("datas", datas);
        judgeAdminOrUser(request, model);
        return "devices/device";
    }

    @RequestMapping(value = "/findDevice2Update", method = {RequestMethod.GET, RequestMethod.POST})
    public String findDevice2Update(HttpServletRequest request, Model model, @RequestParam(value = "page", defaultValue = "0") Integer page,
                                    @RequestParam(value = "size", defaultValue = "15") Integer size,
                                    @RequestParam(defaultValue = "") String sections, DeviceQuery deviceQuery,String status) {
        if (StringUtils.hasLength(status)) {
            List<String> list1 = Arrays.asList(status.split(","));
            List arrList = new ArrayList(list1);
            for(int i = 0;i < list1.size();i++){
                if (arrList.get(i) == "正常" || "正常".equals(arrList.get(i))){
                    arrList.remove(i);
                    arrList.add(i,"0");
                } else if(arrList.get(i) == "报修" || "报修".equals(arrList.get(i))){
                    arrList.remove(i);
                    arrList.add(i,"1");
                } else if(arrList.get(i) == "在修" || "在修".equals(arrList.get(i))){
                    arrList.remove(i);
                    arrList.add(i,"2");
                } else if(arrList.get(i) == "已损坏" || "已损坏".equals(arrList.get(i))){
                    arrList.remove(i);
                    arrList.add(i,"3");
                } else {
                    arrList.remove(i);
                    arrList.add(i,"4");
                }
            }
            deviceQuery.setStatus(arrList);
        }
        if (StringUtils.hasLength(sections)) {
            List<String> list = Arrays.asList(sections.split(","));
            deviceQuery.setSections(list);
        }
        Page<Device> datas = deviceQueryService.findDeviceCriteria(page, size, deviceQuery);
        model.addAttribute("datas", datas);
        judgeAdminOrUser(request, model);
        return "devices/devicelist";
    }

    @RequestMapping("/toEdit")
    public String toEdit(Model model, Integer sn) {
        Device device = deviceQueryService.findBySn(sn);
        model.addAttribute("device", device);
        return "devices/deviceEdit";
    }

    @RequestMapping("/edit")
    public String edit(@RequestParam("file") MultipartFile file, Device device) throws IOException {
        Device device1 = deviceQueryService.findBySn(device.getSn());
        device1.setRemarks(device.getRemarks());
        device1.setStatus(device.getStatus());
        device1.setCustodian(device.getCustodian());
        device1.setDescription(device.getDescription());
        if (!file.isEmpty()) {
//            File savedFile = new File("E:\\myimgs", file.getOriginalFilename());
            File savedFile = new File("/opt/devicesinfo/deviceImg/", file.getOriginalFilename());
            savedFile.setWritable(true, false);
            savedFile.setReadable(true, false);
            FileUtils.copyInputStreamToFile(file.getInputStream(), savedFile);
            if (LoginController.isDebug) {

                dPicPath = LoginController.domainTest + file.getOriginalFilename();
            } else {
                dPicPath = LoginController.domain + "static/" + file.getOriginalFilename();
            }
            device1.setDpic(dPicPath);
        }
        deviceQueryService.edit(device1);
        return "redirect:/eswmp/findDevice2Update";
    }

    @RequestMapping(value = "/findUserQuery", method = {RequestMethod.GET, RequestMethod.POST})
    public String findUserQuery(HttpServletRequest request, Model model, @RequestParam(value = "page", defaultValue = "0") Integer page,
                                @RequestParam(value = "size", defaultValue = "15") Integer size, UserQuery userQuery) {
        Page<User> datas = userQueryService.findUserCriteria(page, size, userQuery);
        model.addAttribute("datas", datas);
        judgeAdminOrUser(request, model);
        return "user/userlist";
    }

    /*@RequestMapping(value = "/findOperatingQuery", method = {RequestMethod.GET, RequestMethod.POST})
    public String findOperatingQuery(HttpServletRequest request, Model model, @RequestParam(value = "page", defaultValue = "0") Integer page,
                                     @RequestParam(value = "size", defaultValue = "15") Integer size, @RequestParam(defaultValue = "") String scanner
            , @RequestParam(defaultValue = "") String section, @RequestParam(defaultValue = "") String ne1did
            , @RequestParam(defaultValue = "1949-10-01") @DateTimeFormat(pattern = "yyyy-MM-dd") String beginTime
            , @RequestParam(defaultValue = "2100-01-01") @DateTimeFormat(pattern = "yyyy-MM-dd") String endTime) {
        Page<OperatingPlusSection> datas = operatingPlusSectionRepository.findLike(new PageRequest(page, size), section, ne1did, beginTime, endTime, scanner);
        model.addAttribute("datas", datas);
        judgeAdminOrUser(request, model);
        return "operating/operating";
    }*/

    @RequestMapping(value = "/findOperatingQuery", method = {RequestMethod.GET, RequestMethod.POST})
    public String findOperatingQuery(HttpServletRequest request, Model model, @RequestParam(value = "page", defaultValue = "0") Integer page,
                                     @RequestParam(value = "size", defaultValue = "15") Integer size, OperatingQuery operatingQuery) {
        Page<Operating> datas = operatingQueryService.findOperatingCriteria(page, size, operatingQuery);
        model.addAttribute("datas", datas);
        judgeAdminOrUser(request, model);
        return "operating/operating";
    }

    @RequestMapping(value = "/findOperatingForManage", method = {RequestMethod.GET, RequestMethod.POST})
    public String findOperatingForManage(HttpServletRequest request, Model model,
                                         @RequestParam(value = "page", defaultValue = "0") Integer page,
                                         @RequestParam(value = "size", defaultValue = "15") Integer size,
                                         @RequestParam(defaultValue = "")String dname, @RequestParam(defaultValue = "") String did,
                                         @RequestParam(defaultValue = "") String ne1did, @RequestParam(defaultValue = "") String owner,
                                         @RequestParam(defaultValue = "") String section, @RequestParam(defaultValue = "") String custodian,
                                         @RequestParam(defaultValue = "") String description, @RequestParam(defaultValue = "") String uaesdid,
                                         @RequestParam(defaultValue = "") String status,DeviceQuery deviceQuery,
                                         @RequestParam(defaultValue = "1949-10-01") @DateTimeFormat(pattern = "yyyy-MM-dd") String beginTime,
                                         @RequestParam(defaultValue = "2100-01-01") @DateTimeFormat(pattern = "yyyy-MM-dd") String endTime) {
        String [] sections = null;
        if (StringUtils.hasLength(section)) {
            sections = section.split(",");
        } else {
            List<String> s = getSelectContentsDao.getSections();
            if(s.size() > 0){
                sections = new String [s.size()];
                for(int i = 0;i < s.size();i++){
                    sections[i] = s.get(i);
                }
            }
        }
        String [] statuss = null;
        if (StringUtils.hasLength(status)) {
            statuss = status.split(",");
            for(int i = 0;i < statuss.length;i++){
                if (statuss[i] == "正常" || "正常".equals(statuss[i])){
                    statuss[i] = "0";
                } else if(statuss[i] == "报修" || "报修".equals(statuss[i])){
                    statuss[i] = "1";
                } else if(statuss[i] == "在修" || "在修".equals(statuss[i])){
                    statuss[i] = "2";
                } else if(statuss[i] == "已损坏" || "已损坏".equals(statuss[i])){
                    statuss[i] = "3";
                } else {
                    statuss[i] = "4";
                }
            }
        } else {
            //如果不选，默认就是查询全部
            statuss = new String[]{"0","1","2","3"};
        }

        Page<Object[]> datas = operatingRepository.findConditions(dname, did, ne1did, owner,statuss,custodian,sections,description,uaesdid,
                beginTime,endTime,new PageRequest(page, size));

        //Map<String,String> paramMap = new HashMap<String,String>(16);
        //paramMap.put("dname", dname);
        model.addAttribute("dname", dname);
        model.addAttribute("datas", datas);
        judgeAdminOrUser(request, model);
        return "operatingForManage/operating";
    }

    @GetMapping(path = "/openid")
    public @ResponseBody
    String getWechatOpenId(@RequestParam String code) {
        System.out.println("..................code = [" + code + "]");
        String APPID = "wxea978169139a4a36";
        String AppSecret = "908851e5525a74cfe3ce259a14beb941";
        String URL = "https://api.weixin.qq.com/sns/jscode2session?appid=" + APPID + "&secret=" + AppSecret + "&js_code=" + code + "&grant_type=authorization_code";
        String result = HttpUtils.doGet(URL);
        return result;

    }

    @PostMapping("getSections")
    @ResponseBody
    public List<String> getSections() {
        return getSelectContentsDao.getSections();
    }

    @PostMapping("getStatus")
    @ResponseBody
    public List<String> getStatus() {
        return getSelectContentsDao.getDeviceStatus();
    }

    @GetMapping("/toDelete")
    public String toDelete(Integer id, String filename) {
        deviceCusRepository.deleteBySn(id);
        if (filename.contains("static")) {
            String fileNameSuffix = filename.split("static")[1];
            String filepath = "/opt/devicesinfo/qrcode" + fileNameSuffix;
            File file = new File(filepath);
            if (file.exists() && file.isFile()) {
                boolean b = file.delete();
                //log.info("fileName:{} delete successful! {}", filepath, b);
            }
        }
        return "redirect:findDevice2Update";
    }

    private void judgeAdminOrUser(HttpServletRequest request, Model model) {
        HttpSession session = request.getSession(true);
        String username = (String) session.getAttribute("username");
        List<User> listUser = userRepository.findByEname(username);
        if (listUser.size() > 0 && listUser.get(0).getUgroup().equalsIgnoreCase("admin")) {
            model.addAttribute("judgeAdminOrUser", "admin");
        } else {
            model.addAttribute("judgeAdminOrUser", "user");
        }
    }

    @RequestMapping(value = "/updateQRPath")
    private @ResponseBody String updateQRPath(){
        try{
            List<Device> list = deviceCusRepository.findAllBy();
            Device device = null;
            for(int i = 0;i < list.size();i++){
                device = list.get(i);
                if(device.getPrcodepath().length() == 77){
                    return "success";
                }
                String [] paths = device.getPrcodepath().split("static");
                String path = "https://www.uaes.site/BD-001-deviceadmin/static" + paths[1];
                device.setPrcodepath(path);
                deviceCusRepository.save(device);
            }
        }catch(Exception e){
            e.printStackTrace();
            return "fail";
        }
        return "success";
    }

    @RequestMapping(value = "/getVersion")
    public @ResponseBody String getVersion(){
        return version;
    }

    @RequestMapping(value = "/getTurnoverRate")
    public @ResponseBody String getTurnoverRate(){
        DeviceTurnoverRateTask deviceTurnoverRateTask = new DeviceTurnoverRateTask();
        deviceTurnoverRateTask.CountDevice();
        return "success";
    }

}
