package com.uaes.controller;

import com.uaes.entity.Department;
import com.uaes.service.DepartmentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Slf4j
@Controller
@RequestMapping(path = "/department")
public class DepartmentControl {

    @Autowired
    private DepartmentService departmentService;

    @RequestMapping(value = "/getDepartment", method = RequestMethod.GET)
    public String findDevice2Update(HttpServletRequest request, Model model, @RequestParam(value = "page", defaultValue = "0") Integer page,
                                    @RequestParam(value = "size", defaultValue = "15") Integer size,Department department) {

//        if (org.springframework.util.StringUtils.hasLength(sections)) {
//            List<String> list = Arrays.asList(sections.split(","));
//            deviceQuery.setSections(list);
//        }
        Page<Department> datas = departmentService.findDepartmentCriteria(page, size, department);
        model.addAttribute("datas", datas);
        //judgeAdminOrUser(request, model);
        return "departments/departmentlist";
    }

    @RequestMapping(path = "/addDepartment")
    public String addDepartment(@RequestParam(value = "department") String department){
        System.out.print("+++++++++++++++++++++++++++++++++++++++++++++");
        //根据名字查询科室是否已经存在
        List<Department> list = departmentService.getDepartmentByName(department);
        Department depart = null;
        if(list.size() > 0){//表示数据库里此科室已存在
            Integer isDeleted = list.get(0).getIsdelted();
            if (isDeleted == 0){//表示此科室已经存在并且在使用
                return "redirect:getDepartment";
            } else {//表示此科室存在，但是已经被删除
                depart = list.get(0);
                depart.setIsdelted(0);
                try{
                    departmentService.saveDepartment(depart);
                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        } else {
            depart = new Department();
            depart.setDepartment(department);
            depart.setIsdelted(0);
            departmentService.saveDepartment(depart);
        }
        return "redirect:getDepartment";
    }

    @GetMapping(path = "/toAdd")
    public String toAdd(Model model){
        Department department = new Department();
        model.addAttribute("depart",department);
        return "departments/departmentEdit";
    }

    @RequestMapping(path = "/updateDepartment")
    public String updateDepartment(@RequestParam String id,@RequestParam String department){
        if(id != null && !"".equals(id)){
            Department depart = departmentService.getDepartmentById(id);
            depart.setDepartment(department);
            departmentService.saveDepartment(depart);
        }
        return "redirect:getDepartment";
    }

    @GetMapping(path = "/toUpdate")
    public String toUpdate(@RequestParam String id,Model model){
        if(id != null && !"".equals(id)){
            Department depart = departmentService.getDepartmentById(id);
            model.addAttribute("depart", depart);
        }
        return "departments/departmentEdit";
    }

    @GetMapping(path = "/deleteDepartment")
    public String deleteDepartment(@RequestParam String ids){
        if(ids != null && !"".equals(ids)){
            //String [] id = ids.split(",");
            departmentService.deleteDepartment(ids);
        }
        return "redirect:getDepartment";
    }
}
