package com.uaes.controller;

import com.uaes.entity.PrintQRcode;
import com.uaes.repository.PrintQRcodeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping(path = "/eswmp")
public class PrintQRcodeControl {

    @Autowired
    private PrintQRcodeRepository printQRcodeRepository;
    SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

    @RequestMapping(path = "/savePrintQRcode")
    public @ResponseBody String savePrintQRcode(HttpServletRequest request, Model model){
        PrintQRcode printQRcode = null;
        SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        //request.setCharacterEncoding("utf-8");
        String dname = request.getParameter("dname");
        String uaesdid = request.getParameter("uaesdid");
        String ne1did = request.getParameter("ne1did");
        String qrcodePath = request.getParameter("qrcodePath");
        String registerUser = request.getParameter("registerUser");

        try {
            List<PrintQRcode> l = printQRcodeRepository.findPrintByParam(dname,ne1did,registerUser);
            if(l.size() > 0){
                if(l.get(0).getPrintstatus() == 1){//如果用户已经申请，并且已经被打印过了，此时再次改变状态为0
                    //String printTime = sf.format(new Date());
                    printQRcodeRepository.updatePrintQRcodeStatus("", String.valueOf(l.get(0).getId()),0);
                }
                return "success";
            }
            printQRcode = new PrintQRcode();
            printQRcode.setDevicename(dname);
            printQRcode.setNe1did(ne1did);
            printQRcode.setQrcodepath(qrcodePath);
            printQRcode.setUaesdid(uaesdid);
            printQRcode.setRegistertime(sf.format(new Date()));
            printQRcode.setPrintstatus(0);
            printQRcode.setRegisteruser(registerUser);
            printQRcodeRepository.save(printQRcode);
        } catch (Exception e){
            e.printStackTrace();
        }
        return "success";
    }

    @GetMapping(path="/getAllPrintQRcode") // Map ONLY GET Requests
    public @ResponseBody Iterable<PrintQRcode> getAllPrintQRcode (@RequestParam(value = "page", defaultValue = "0")Integer page,
                                                            @RequestParam(value = "size", defaultValue = "15") Integer size) {
        Pageable pageable = new PageRequest(page, size, Sort.Direction.ASC, "id");
        System.out.println("xxxxxxxxxxx:"+printQRcodeRepository.findAll(pageable));
        //Iterable<PrintQRcode> ls = printQRcodeRepository.findAll(pageable);
        return printQRcodeRepository.findAll(pageable);

    }

    @GetMapping(path = "/updatePrintQRcodeStatus")
    public @ResponseBody int updatePrintQRcodeStatus(HttpServletRequest request){
        String id = request.getParameter("id");
        String printTime = sf.format(new Date());
        int num = printQRcodeRepository.updatePrintQRcodeStatus(printTime,id,1);
        return num;
    }

    @GetMapping(path="/getPrintQRcodeBykeyword")
    public @ResponseBody Iterable<PrintQRcode> getPrintQRcodeBykeyword(@RequestParam String keyword) {
        // This returns a JSON or XML with the users
//        System.out.println("..................eid = [" + ne1did + "]"+dec);
        Iterable<PrintQRcode> l = printQRcodeRepository.findByDevicenameLikeOrUaesdidLikeOrRegisteruserLike("%"+keyword+"%","%"+keyword+"%","%"+keyword+"%");
        return l;
    }

    @GetMapping(path = "/getAllPrintQDForWX") // Map ONLY GET Requests
    public @ResponseBody
    Page<Object[]> getAllPrintQDForWX(@RequestParam(value = "page", defaultValue = "0") Integer page,
                                  @RequestParam(value = "size", defaultValue = "15") Integer size,
                                  @RequestParam(defaultValue = "")String dname, @RequestParam(defaultValue = "") String uaesdid,
                                  @RequestParam(defaultValue = "") String registerUser){
        Page<Object[]> p = printQRcodeRepository.getAllPrintQDForWX(dname,uaesdid,registerUser,new PageRequest(page, size));
        return p;
    }
}
