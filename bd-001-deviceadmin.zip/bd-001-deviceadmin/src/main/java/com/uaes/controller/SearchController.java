package com.uaes.controller;

import com.uaes.entity.User;
import com.uaes.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping(path="/search")
public class SearchController {
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private DeviceCusRepository deviceCusRepository;
    @Autowired
    private OperatingRepository operatingRepository;

    @GetMapping(path="/getuserbykeyword")
    public @ResponseBody Iterable<User> getUserBykeyword(@RequestParam String keyword) {
        System.out.println("..................keyword = [" + keyword + "]");
        return userRepository.findByEnameLikeAndUgroup("%"+keyword+"%","user");

    }
    @GetMapping(path="/adminlist")
    public @ResponseBody Iterable<User> getAdmin() {

        return userRepository.findByUgroup("admin");
    }
    @GetMapping(path="/deleteadmin")
    @ResponseBody
    public String deleteAdmin(@RequestParam int sn) {
        int res= userRepository.updateAdmin(sn,"user");
        System.out.println("sn="+sn);
        return String.valueOf(res);
    }
    @PostMapping(path="/addadmin")
    public String  addAdmin(HttpServletRequest request,Model model, String adminname) {

        int res = userRepository.setAdmin(adminname,"admin");
        if(res == 1){
            return "redirect:/user/admin";
        }else{
            String mess = "添加失败";
            model.addAttribute("mess",mess);
            return "redirect:/user/admin";
        }
    }
}
