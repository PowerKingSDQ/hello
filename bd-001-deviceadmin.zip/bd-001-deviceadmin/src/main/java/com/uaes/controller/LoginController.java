package com.uaes.controller;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import net.coobird.thumbnailator.Thumbnails;
import net.coobird.thumbnailator.geometry.Positions;
import net.sf.json.JSONObject;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.awt.*;
import java.awt.font.FontRenderContext;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

@Controller
public class LoginController {

    public static int i = 0;
    public final static String domain = "https://www.uaes.site/BD-001-deviceadmin/";
    public final static String domainTest = "http://localhost:8030/BD-001-deviceadmin/";
    public static boolean isDebug = false;
    private static String filePath = null;
    private static String fileName = null;
    private static String imgUrl = null;
    private static String linuxQrcodePath = "/opt/devicesinfo/qrcodeImg/qrcode/";
    private static String linuxPicTempPath = "/opt/devicesinfo/qrcodeImg/temp/";
    private static String imageLinuxPilePath = "/opt/devicesinfo/qrcodeImg/images/";
    private static String windowQrcodeTempPath = "static/qrcode/qrcode";
    private static String windowPicTempPath = "static/qrcode/temp";
    private static String imageWindowPilePath = "static/qrcode/images";

    @Value("${server.display-name}")
    String version;

    /**
     * @Description (TODO)
     */
    @PostMapping("/login")
    public String LoginOperation(HttpServletRequest request, Model model, String username,
                                 String password) {
        String desc = "认证通过";
        //String result;
        System.out.println("操作人" + username);
        String strObj = getWebServerInfo(username, password);
        JSONObject myJsonObject = JSONObject.fromObject(strObj);
        desc = myJsonObject.getString("desc");
        //result = myJsonObject.getString("result");
        if (desc.equals("认证通过")) {
            HttpSession session = request.getSession();
            session.setAttribute("username", username);
            session.setAttribute("version", version);
            return "redirect:eswmp/findDeviceQuery";
        } else {
            String mess = "账号或者密码错误";
            model.addAttribute("mess", mess);
            return "user/index";
        }
    }

    @RequestMapping("/getSessionVersion")
    public @ResponseBody String getSessionVersion(HttpServletRequest request, HttpServletResponse response){
        //编码规范
        response.setContentType("text/html;charset=utf-8");
        response.setCharacterEncoding("utf-8");
        //获取session值
        HttpSession session = request.getSession();
        Object user = session.getAttribute("version");
        try {
            return user.toString();
        }catch (Exception e){
            System.out.println("Nothing session");
            return null;
        }
    }

    /**
     * @Description (TODO)
     */
    public static String getWebServerInfo(String strUserName, String strPassword) {

        String nameSpace = "http://service.auth.idm.com";

        String methodName = "validate";

        String endPoint = "http://ohs.uaes.com:7777/LdapWebService/services/LdapAuthService";

        String soapAction = "http://service.auth.idm.com/validate";

        SoapObject rpc = new SoapObject(nameSpace, methodName);

        rpc.addProperty("adminname", "admin");
        rpc.addProperty("adminpwd", "uaes,123");
        rpc.addProperty("username", strUserName);
        rpc.addProperty("password ", strPassword);

        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER10);

        envelope.bodyOut = rpc;

        envelope.dotNet = true;

        envelope.setOutputSoapObject(rpc);

        HttpTransportSE transport = new HttpTransportSE(endPoint);
        try {

            transport.call(soapAction, envelope);
        } catch (Exception e) {
            e.printStackTrace();
        }

        SoapObject object = (SoapObject) envelope.bodyIn;

        String result = null;
        if (object != null) {
            result = object.getProperty(0).toString();
        }
        return result;
    }

    

    public static int getNE1DID() throws IOException {
        String strValue = "";
        InputStreamReader read = null;
        BufferedReader bufferedReader = null;
        try {
            File file = new File("//opt//devicesinfo//version.txt");
            String encoding = "GBK";
            if (file.isFile() && file.exists()) { //判断文件是否存在
                read = new InputStreamReader(
                        new FileInputStream(file), encoding);//考虑到编码格式
                bufferedReader = new BufferedReader(read);

                String lineTxt = null;
                while ((lineTxt = bufferedReader.readLine()) != null) {
                    System.out.println(lineTxt);
                    strValue = lineTxt;
                }

            } else {
                System.out.println("找不到指定的文件");
            }
        } catch (Exception e) {
            System.out.println("读取文件内容出错");
            e.printStackTrace();
        } finally {
            if (read != null) {
                read.close();
            }
            if (bufferedReader != null) {
                bufferedReader.close();
            }
        }
        return Integer.parseInt(strValue);
    }

    public static void saveNE1DID(int NE1DID) throws IOException {
        String content = String.valueOf(NE1DID);
        try {
            File file = new File("//opt//devicesinfo//version.txt");
            if (file.isFile() && file.exists()) { //判断文件是否存在
                FileWriter fw = new FileWriter(file);
                BufferedWriter bw = new BufferedWriter(fw);
                bw.write(content);
                bw.flush();
                bw.close();
            } else {
                System.out.println("找不到指定的文件");
            }
        } catch (Exception e) {
            System.out.println("读取文件内容出错");
            e.printStackTrace();
        }
    }

    //    @PostMapping("/qrcode")
    public static String qrcode(String dname, String uaesdid, String NE1did, Model model)
            throws Exception {
        File file = new File(ResourceUtils.getURL("classpath:").getPath());
        String filePath1 = null;
        String picPath = null;

        if (isDebug) {
            if (!file.exists()) {
                file = new File("");
            }
            File upload = new File(file.getAbsolutePath(), "/static/qrcode/upload");
            if (!upload.exists()) {
                upload.mkdirs();
            }
            File qrcode = new File(file.getAbsolutePath(), "/static/qrcode/qrcode");
            if (!qrcode.exists()) {
                qrcode.mkdirs();
            }
            File temp = new File(file.getAbsolutePath(), "/static/qrcode/temp");
            if (!temp.exists()) {
                temp.mkdirs();
            }
            File images = new File(file.getAbsolutePath(), "/static/qrcode/images");
            if (!images.exists()) {
                images.mkdirs();
            }
            //String filePath = "C:\\360";
            filePath1 = upload.getAbsolutePath();
            System.out.println("filePath" + filePath1);
            //String string = filePath1.substring(filePath1.length() - 21, filePath1.length());
            //String string = "D:\\SW\\IdeaProject\\bd-001-device\\src\\main\\resources";
            //System.out.println("string" + string);
            fileName = NE1did + ".png";
            filePath = ResourceUtils.getURL("classpath:").getPath() + windowQrcodeTempPath;
            System.out.println(NE1did);
            //imgUrl = domainTest + string + "/" + fileName;
            imgUrl = ResourceUtils.getURL("classpath:").getPath() + windowQrcodeTempPath + "/" + fileName;
            picPath = windowPicTempPath + "/temp.png";
            picPath = new File(ResourceUtils.getURL("classpath:").getPath()).getAbsolutePath() + "/"+ picPath;
        } else {
            File qrcode = new File("/opt/devicesinfo/qrcodeImg/qrcode");
            if (!qrcode.exists()) {
                qrcode.mkdirs();
            }
            File temp = new File("/opt/devicesinfo/qrcodeImg/temp");
            if (!temp.exists()) {
                temp.mkdirs();
            }
            File images = new File("/opt/devicesinfo/qrcodeImg/images");
            if (!images.exists()) {
                images.mkdirs();
            }
            filePath = linuxQrcodePath;
            fileName = NE1did + ".png";
            System.out.print(NE1did);
            imgUrl = domain + "static/qrcodeImg/images/" + fileName;
            picPath = linuxPicTempPath + "/temp.png";
        }
        model.addAttribute("imgUrl", imgUrl);
        model.addAttribute("dname", dname);
        model.addAttribute("ne1did", NE1did);
        org.json.JSONObject jsonObject = new org.json.JSONObject();
        jsonObject.put("type", "device");
        jsonObject.put("dname", dname);
        jsonObject.put("ne1did", NE1did);
        String content = jsonObject.toString();
        int width = 300;
        int height = 300;
        String format = "png";
        Map<EncodeHintType, Object> hints = new HashMap<EncodeHintType, Object>();
        hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
        BitMatrix bitMatrix = new MultiFormatWriter().encode(content, BarcodeFormat.QR_CODE, width, height, hints);
        //Path path = Paths.get(filePath + fileName);
        //Path path = Paths.get(filePath + "/" + fileName);
        Path path = null;
        if (isDebug){
            //本地调试环境
            filePath = ResourceUtils.getURL("classpath:").getPath() + windowQrcodeTempPath;
            String aa = new File(filePath).getAbsolutePath();
            path = Paths.get(aa + "/" + fileName);
        } else {
            //服务器环境
            path = Paths.get(linuxQrcodePath + "/" + fileName);
        }
        //Path path = Paths.get("D:\\SW\\IdeaProject\\bd-001-deviceadmin\\src\\main\\resources"+filePath + "/" + fileName);
        System.out.println("path=" + path);
        //生成二维码
        MatrixToImageWriter.writeToPath(bitMatrix, format, path);
        //生成左边数据  设备名称/固定资产编号/NE1000008
        createImage(dname,uaesdid,NE1did);
        //String[] files = {"D:\\pic.png","D:\\qrcode.png"};
        //String targetFile = "D:\\targetFile.png";
        String[] files = {picPath,path.toString()};
        String targetFile = null;
        //本地测试环境这么写start
        if (isDebug) {
            //本地调试环境
            targetFile = ResourceUtils.getURL("classpath:").getPath() + imageWindowPilePath+"/" + NE1did + ".png";
            //String targetFilePath = new File(targetFile).getAbsolutePath();
        } else {
            //服务器环境
            targetFile = imageLinuxPilePath + "/" + NE1did + ".png";
        }
        //合成最终图片  文字+二维码
        mergeImage(files,1,targetFile);
//      以下代码往二维码图片里插入文字
//      start
//      String insertContent = dname + " / " + NE1did;
//      drawStringForImage(path + "", insertContent, Color.BLACK, 0.9f, path + "");
//      insert2Image(path + "", insertContent);
//      end
        System.out.println("输出成功");
        return "qrcode/qrcode";
    }

    public static void mergeImage(String[] files, int type, String targetFile) {
        int len = files.length;
        if (len < 1) {
            throw new RuntimeException("图片数量小于1");
        }
        File[] src = new File[len];
        BufferedImage[] images = new BufferedImage[len];
        int[][] ImageArrays = new int[len][];
        for (int i = 0; i < len; i++) {
            try {
                src[i] = new File(files[i]);
                images[i] = ImageIO.read(src[i]);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            int width = images[i].getWidth();
            int height = images[i].getHeight();
            ImageArrays[i] = new int[width * height];
            ImageArrays[i] = images[i].getRGB(0, 0, width, height, ImageArrays[i], 0, width);
        }
        int newHeight = 0;
        int newWidth = 0;
        for (int i = 0; i < images.length; i++) {
            // 横向
            if (type == 1) {
                newHeight = newHeight > images[i].getHeight() ? newHeight : images[i].getHeight();
                newWidth += images[i].getWidth();
            } else if (type == 2) {// 纵向
                newWidth = newWidth > images[i].getWidth() ? newWidth : images[i].getWidth();
                newHeight += images[i].getHeight();
            }
        }
        if (type == 1 && newWidth < 1) {
            return;
        }
        if (type == 2 && newHeight < 1) {
            return;
        }

        // 生成新图片
        try {
            BufferedImage ImageNew = new BufferedImage(newWidth, newHeight, BufferedImage.TYPE_INT_RGB);
            int height_i = 0;
            int width_i = 0;
            for (int i = 0; i < images.length; i++) {
                if (type == 1) {
                    ImageNew.setRGB(width_i, 0, images[i].getWidth(), newHeight, ImageArrays[i], 0,
                            images[i].getWidth());
                    width_i += images[i].getWidth();
                } else if (type == 2) {
                    ImageNew.setRGB(0, height_i, newWidth, images[i].getHeight(), ImageArrays[i], 0, newWidth);
                    height_i += images[i].getHeight();

                }
            }
            Graphics g = ImageNew.getGraphics();
            g.setFont(new Font("宋体",Font.BOLD,25));
            g.dispose();
            ImageNew.flush();
            //输出想要的图片
            ImageIO.write(ImageNew, targetFile.split("\\.")[1], new File(targetFile));

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static void createImage(String dname,String uaesdid,String ne1did) throws IOException {
        File file = null;
        if(isDebug){
            String aaa = ResourceUtils.getURL("classpath:").getPath() + windowPicTempPath;
            String aa = new File(aaa).getAbsolutePath();
            file = new File(aa + "/temp.png");
        } else{
            file = new File(linuxPicTempPath +"/temp.png");
        }
        System.out.println("设备名字为:" + dname + "!!!!!!!!!!!!!!!!!!!!!!!!!!");
        Font font = new Font("宋体", Font.BOLD, 30);
        BufferedImage bi = new BufferedImage(300, 300, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2 = (Graphics2D) bi.getGraphics();
        g2.setBackground(Color.WHITE);
        g2.clearRect(0, 0, 300, 300);
        g2.setPaint(Color.BLACK);
        g2.setFont(font);
        FontRenderContext context = g2.getFontRenderContext();
        Rectangle2D bounds = font.getStringBounds(dname, context);
        double x = (300 - bounds.getWidth()) / 2;
        double y = (300 - bounds.getHeight()) / 2;
        double y1 = (150 - bounds.getHeight()) / 2;
        double y2 = (450 - bounds.getHeight()) / 2;
        double ascent = -bounds.getY();
        g2.drawString(uaesdid, (int) x, (int) (y + ascent));
        g2.drawString(dname, (int) x, (int) (y1 + ascent));
        g2.drawString(ne1did, (int) x, (int) (y2 + ascent));
        ImageIO.write(bi, "png", file);
    }

    private static void insert2Image(String path, String insertContent) throws IOException {
        BufferedImage bi = new BufferedImage(250, 30, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = bi.createGraphics();
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, 250, 30);//填充整个屏幕
        g.setColor(Color.BLACK);
        g.scale(1.5, 1.5); //压缩或放大图片
        char[] data = insertContent.toCharArray();
        g.drawChars(data, 0, data.length, 10, 15);
        Thumbnails.of(path).size(300, 300)
                .watermark(Positions.BOTTOM_CENTER, bi, 0.9f)
                .toFile(new File(path));

    }

//    private static void drawStringForImage(String filePath, String content, Color contentColor, float qualityNum, String targetFile) {
//        ImageIcon imgIcon = new ImageIcon(filePath);
//        Image theImg = imgIcon.getImage();
//        int width = theImg.getWidth(null) == -1 ? 300 : theImg.getWidth(null);
//        int height = theImg.getHeight(null) == -1 ? 300 : theImg.getHeight(null);
//        BufferedImage bufferedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
//        Graphics2D g = bufferedImage.createGraphics();
//        g.setColor(contentColor);
//        //g.setBackground(Color.red);
//        g.drawImage(theImg, 0, 0, null);
//        // 设置字体、字型、字号
//        g.setFont(new Font(null, Font.BOLD, 14));
//        // 写入文字
//        g.drawString(content, 35, 290);
//        g.dispose();
//        FileOutputStream out = null;
//        try {
//            out = new FileOutputStream(targetFile);
//            JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(out);
//            JPEGEncodeParam param = encoder.getDefaultJPEGEncodeParam(bufferedImage);
//            param.setQuality(qualityNum, true);
//            encoder.encode(bufferedImage, param);
//            out.flush();
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (out != null) {
//                try {
//                    out.close();
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//            }
//        }
//    }
}
