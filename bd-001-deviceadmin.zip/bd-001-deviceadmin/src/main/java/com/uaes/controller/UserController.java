package com.uaes.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping(value = "/user")
public class UserController {

    @RequestMapping(value = "/index")
    public String index(){
        return "user/index";
    }
    @RequestMapping(value = "/userlist")
    public String userlist() {
        return "user/userlist";
    }

    @RequestMapping(value = "/operating")
    public String operating() {
        return "operating/operating";
    }

    @RequestMapping(value = "/device")
    public String device() {

        return "devices/device";
    }

    @RequestMapping(value = "/qrcode")
    public String qrcode() {
        return "qrcode/qrcode";
    }
    @RequestMapping(value = "/admin")
    public String admin() {
        return "user/admin";
    }
    @RequestMapping(value = "/generaluser")
    public String generaluser() {
        return "generaluser/generaluser";
    }
}
