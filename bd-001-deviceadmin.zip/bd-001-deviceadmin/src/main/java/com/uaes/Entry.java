package com.uaes;

//import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;

//@EnableEurekaClient
//@SpringBootApplication
//@EnableScheduling
//@ComponentScan(basePackages = "com.uaes")
//public class Entry extends SpringBootServletInitializer {
//    @Override
//    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
//        return builder.sources(Entry.class);
//    }
//
//    public static void main(String[] args) throws Exception {
//        SpringApplication.run(Entry.class, args);
//    }
//}
//本地调试打开  关闭上面的代码
//@EnableEurekaClient
@SpringBootApplication
@EnableScheduling
@ComponentScan(basePackages = "com.uaes")
public class Entry {
    public static void main(String[] args) throws Exception {
        SpringApplication.run(Entry.class, args);
    }
}
