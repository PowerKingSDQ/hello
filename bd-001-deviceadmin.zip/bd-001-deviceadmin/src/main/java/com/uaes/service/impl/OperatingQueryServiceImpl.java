package com.uaes.service.impl;

import com.uaes.entity.Operating;
import com.uaes.entity.OperatingQuery;
import com.uaes.service.OperatingQueryService;
import com.uaes.repository.OperatingRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

@Service(value = "operatingQueryService")
public class OperatingQueryServiceImpl implements OperatingQueryService {
    @Resource
    OperatingRepository operatingRepository;

    @Override
    public Page<Operating> findOperatingCriteria(Integer page, Integer size, OperatingQuery operatingQuery) {
        Pageable pageable = new PageRequest(page, size, Sort.Direction.ASC, "sn");
        Page<Operating> operatingPage = operatingRepository.findAll(new Specification<Operating>() {
            @Override
            public Predicate toPredicate(Root<Operating> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> list = new ArrayList<Predicate>();
                if (StringUtils.hasLength(operatingQuery.getNe1did())) {
                    list.add(cb.like(root.get("ne1did").as(String.class), "%" + operatingQuery.getNe1did() + "%"));
                }
                if (StringUtils.hasLength(operatingQuery.getScanner())) {
                    list.add(cb.like(root.get("scanner").as(String.class), "%" + operatingQuery.getScanner() + "%"));
                }
                if (StringUtils.hasLength(operatingQuery.getOperatingtype())) {
                    list.add(cb.like(root.get("operatingtype").as(String.class), "%" + operatingQuery.getOperatingtype() + "%"));
                }
                if (StringUtils.hasLength(operatingQuery.getDescription())) {
                    list.add(cb.like(root.get("description").as(String.class), "%" + operatingQuery.getDescription() + "%"));
                }
                if (org.apache.commons.lang.StringUtils.isNotEmpty(operatingQuery.getBeginTime()) && org.apache.commons.lang.StringUtils.isNotEmpty(operatingQuery.getEndTime())) {
                    list.add(cb.between(root.get("timestamp").as(String.class), operatingQuery.getBeginTime(), operatingQuery.getEndTime()));
                }
                Predicate[] p = new Predicate[list.size()];
                return cb.and(list.toArray(p));
            }
        }, pageable);
        return operatingPage;
    }
}
