package com.uaes.service;

import com.uaes.entity.User;
import com.uaes.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepositoty;

    public User findUserByName(String name){
        User user = null;
        try{
//            user = userRepositoty.findByEid(name);
        }catch (Exception e){}
        return user;
    }
}
