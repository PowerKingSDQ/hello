package com.uaes.service;

import com.uaes.entity.DeviceTurnoverRateVo;
import com.uaes.repository.OperatingRepository;
import org.apache.commons.io.output.ByteArrayOutputStream;
import org.apache.poi.hssf.usermodel.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.DateFormat;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Component
public class DeviceTurnoverRateTask {

    @Autowired
    private OperatingRepository operatingRepository;
    @Autowired
    private MailService mailService;

    List<DeviceTurnoverRateVo> turnoverRatesList = new ArrayList<DeviceTurnoverRateVo>();
    //String beginDate = "2018-04-15";
    //String endDate = "2018-12-31";

    //统计设备转手率
    //@Scheduled(cron = "30 02 14 ? * *")
    public void CountDevice(){
        //先统计ES开头和UAD开头的设备扫描记录
        //没有重复的扫描列表
        List<Object[]> distinctList = operatingRepository.findAllDistictByDateAndName("ES","UAD","UDE","ESW");
        List<Object[]> list = operatingRepository.findAllByDateAndName("ES","UAD","UDE","ESW");
        List<DeviceTurnoverRateVo> distinctDeviceOper = null;
        if(distinctList.size() > 0){
            for(int i = 0;i < distinctList.size();i++){
                String ne1didDistinct = distinctList.get(i)[2] == null ? "" : distinctList.get(i)[2].toString();
                if(list.size() > 0){
                    distinctDeviceOper = new ArrayList<DeviceTurnoverRateVo>();
                    //循环将同样ne1did的设备扫描记录存到list中
                    for(int j = 0;j < list.size();j++){
                        DeviceTurnoverRateVo device = null;
                        String ne1did = list.get(j)[2] == null ? "" : list.get(j)[2].toString();
                        if(ne1did != "" && !"".equals(ne1did) && ne1didDistinct.equals(ne1did)){
                            device = new DeviceTurnoverRateVo();
                            device.setDeviceName(list.get(j)[0] == null ? "" : list.get(j)[0].toString());
                            device.setUaesdid(list.get(j)[1] == null ? "" : list.get(j)[1].toString());
                            device.setNe1did(list.get(j)[2] == null ? "" : list.get(j)[2].toString());
                            device.setOwner(list.get(j)[3] == null ? "" : list.get(j)[3].toString());
                            device.setOwnDate(list.get(j)[4] == null ? "" : list.get(j)[4].toString());
                            distinctDeviceOper.add(device);
                        }
                    }
                    censusDevTurnoverRate(distinctDeviceOper);
                }
            }
        }
        getExcel(turnoverRatesList);
    }

    public void censusDevTurnoverRate(List<DeviceTurnoverRateVo> list){
        //用来统计转手数
        int turnNum = 0;
        int turnDate = 0;
        String ne1did = list.get(0).getNe1did();
        String uaesdid = list.get(0).getUaesdid();
        String devicename = list.get(0).getDeviceName();
        DeviceTurnoverRateVo device = new DeviceTurnoverRateVo();
        if(list.size() > 1){
            String owner = list.get(0).getOwner();
            String ownDate = list.get(0).getOwnDate();
            for(int i = 1;i < list.size();i++){
                String nextOwner = list.get(i).getOwner();
                String nextOwnDate = list.get(i).getOwnDate();
                if(i == list.size() - 1){
                    if(owner.equals(nextOwner)){
                        if(turnNum > 0){
                            //走到此处证明某台设备被某人扫走以后，截止到统计的时候，此设备一直在他手中
                            turnDate = turnDate + compareDate(ownDate,nextOwnDate);
                            ownDate = nextOwnDate;
                        }else{
                            //设备被人扫了很多次，但一直在一个人手里
                            turnNum = 0;
                        }
                    }else{
                        //走到此处证明设备最后一次是被另外人扫走的
                        owner = nextOwner;
                        turnDate = turnDate + compareDate(ownDate,nextOwnDate);
                        ownDate = nextOwnDate;
                        turnNum = turnNum + 1;
                    }
                }else{
                    if(StringUtils.isEmpty(nextOwner) == false && !nextOwner.equals(owner)){
                        //证明有了转接人
                        owner = nextOwner;
                        turnDate = turnDate + compareDate(ownDate,nextOwnDate);
                        ownDate = nextOwnDate;
                        turnNum = turnNum + 1;
                    }else{
                        continue;
                    }
                }
            }
        }else{
            if(list.size() > 0){
                turnNum = 0;
            }else{
                return;
            }
        }
        device.setNe1did(ne1did);
        device.setUaesdid(uaesdid);
        device.setDeviceName(devicename);
        device.setTurnNum(turnNum + "");
        //device.setTurnRate(turnDate/turnNum + "");
        turnoverRatesList.add(device);
    }

    public void getExcel(List<DeviceTurnoverRateVo> turnoverRatesList){
        HSSFWorkbook workbook = new HSSFWorkbook();
        HSSFSheet sheet = workbook.createSheet("统计设备转手率");

        //新增数据行，并且设置单元格数据

        int rowNum = 1;

        //String[] headers = { "设备名称", "UAES固定资产编号", "NE1资产编号", "转手次数", "转手率"};
        String[] headers = { "设备名称", "UAES固定资产编号", "NE1资产编号", "转手次数"};
        //headers表示excel表中第一行的表头

        HSSFRow row = sheet.createRow(0);
        //在excel表中添加表头

        for(int i=0;i<headers.length;i++){
            HSSFCell cell = row.createCell(i);
            HSSFRichTextString text = new HSSFRichTextString(headers[i]);
            cell.setCellValue(text);
        }

        //在表中存放查询到的数据放入对应的列
        for (int i = 0;i < turnoverRatesList.size();i++) {
            HSSFRow row1 = sheet.createRow(rowNum);
            row1.createCell(0).setCellValue(turnoverRatesList.get(i).getDeviceName());
            row1.createCell(1).setCellValue(turnoverRatesList.get(i).getUaesdid());
            row1.createCell(2).setCellValue(turnoverRatesList.get(i).getNe1did());
            row1.createCell(3).setCellValue(turnoverRatesList.get(i).getTurnNum());
            //row1.createCell(4).setCellValue(turnoverRatesList.get(i).getTurnRate());
            rowNum++;
        }

        ByteArrayOutputStream os = new ByteArrayOutputStream();
        try{
            workbook.write(os);
        }
        catch (IOException e){
            e.printStackTrace();
        }

        byte[] content = os.toByteArray();
        File file = new File("D:\\1111.xls");//Excel文件生成后存储的位置。
        OutputStream fos  = null;
        try
        {
            fos = new FileOutputStream(file);
            fos.write(content);
            os.close();
            fos.close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    //根据传入的两个日期计算天数差距
    public int compareDate(String date1,String date2){
        DateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
        ParsePosition pos = new ParsePosition(0);
        ParsePosition pos1 = new ParsePosition(0);
        Date firstDate = format1.parse(date1,pos);
        Date secondDate = format1.parse(date2,pos1);
        Calendar firstCal = Calendar.getInstance();
        Calendar secondCal = Calendar.getInstance();
        firstCal.setTime(firstDate);
        secondCal.setTime(secondDate);
        int day1= firstCal.get(Calendar.DAY_OF_YEAR);
        int day2 = secondCal.get(Calendar.DAY_OF_YEAR);
        int year1 = firstCal.get(Calendar.YEAR);
        int year2 = secondCal.get(Calendar.YEAR);
        if(year1 != year2){
            int timeDistance = 0 ;
            for(int i = year1 ; i < year2 ; i ++)
            {
                if(i%4==0 && i%100!=0 || i%400==0)    //闰年
                {
                    timeDistance += 366;
                }
                else    //不是闰年
                {
                    timeDistance += 365;
                }
            }
            return timeDistance + (day2-day1);
        }else {
            return day2 - day1;
        }
    }
}
