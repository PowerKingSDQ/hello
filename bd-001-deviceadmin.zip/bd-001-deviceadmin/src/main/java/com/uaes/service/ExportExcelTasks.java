package com.uaes.service;

import com.uaes.entity.ExportExcel;
import com.uaes.repository.ExportExcelRepository;
import com.uaes.repository.OperatingRepository;
import org.apache.commons.io.output.ByteArrayOutputStream;
import org.apache.poi.hssf.usermodel.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Component
public class ExportExcelTasks {

    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    private SimpleDateFormat dateFormatHMS = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
    private Logger log = LoggerFactory.getLogger(ScheduledTasks.class);

    @Autowired
    private OperatingRepository operatingRepository;
    @Autowired
    private ExportExcelRepository exportExcelRepository;
    @Autowired
    private MailService mailService;

    @Scheduled(cron = "0 0 12 ? * FRI")
    //"0 10 11 ? * FRI"
    public void exportExcel(){
        log.info("export excel start!....");
        //因为定时任务每周五执行,此时先插入下周需要导出excel文件的信息
        String today = dateFormat.format(new Date());
        String [] todays = today.split("-");
        String year = todays[0];
        String month = todays[1];

        //File file = new File("/opt/operatingExcel/" + year + "/" + month);
        File file = new File("/opt/operatingExcel/" + year + "/" + month);
        if (!file.exists()) {
            file.mkdirs();
        }
        //获取下周五的日期
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE,7);
        String nextFriday = dateFormat.format(c.getTime());
        //获取下下周五之前三十天的日期
        c.add(Calendar.DATE,-30);
        String nextFridayBefore30Day = dateFormat.format(c.getTime());
        //获取今天前三十天的日期
        c.add(Calendar.DATE,-7);
        String todayBefore30Day = dateFormat.format(c.getTime());

        String fileName = "一周扫描记录表" + nextFridayBefore30Day + "至" + nextFriday + ".xls";
        try{
            log.info("生成下周需要发送的excel信息start!....");
            ExportExcel exportExcel = new ExportExcel();
            exportExcel.setPath("/opt/operatingExcel/" + year + "/" + month + "/" + fileName);
            exportExcel.setStatus(0);
            exportExcel.setCreatetime(dateFormatHMS.format(new Date()));
            exportExcel.setTimelimit(nextFridayBefore30Day + "至" + nextFriday);
            exportExcelRepository.save(exportExcel);
            log.info("生成下周需要发送的excel信息end!....");
        } catch (Exception e){
            e.printStackTrace();
        }
        try{
            log.info("查询需要发送邮件的地址!");
            List<ExportExcel> exportExcelList = exportExcelRepository.getDataForExport(todayBefore30Day + "至" + today);
            if(exportExcelList.size() > 0){
                ExportExcel excel = exportExcelList.get(0);
                String path = excel.getPath();
                log.info("发送邮件的附件路径为:" + path);
                //生成本次需要发送的excel文件
                getExcel(todayBefore30Day,today,path);
                //邮件发送附件给指定人
                log.info("发送邮件start!....");
                mailService.sendAttachmentsMail("ext.tian.ding@uaes.com","一周扫描记录统计",
                        "一周扫描记录统计" + todayBefore30Day +"至" + today,path);
                log.info("发送邮件end!....");
                log.info("发送邮件成功后，修改此文件信息的状态为已发送start!....");
                //发送邮件成功后，修改此文件信息的状态为1
                excel.setStatus(1);
                excel.setUpdatetime(dateFormatHMS.format(new Date()));
                exportExcelRepository.save(excel);
                log.info("发送邮件成功后，修改此文件信息的状态为已发送end!....");
            } else {
                log.info("数据库找不到要发送的文件记录信息!");
            }
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    public void getExcel(String beginDate,String endDate,String path){
        HSSFWorkbook workbook = new HSSFWorkbook();
        HSSFSheet sheet = workbook.createSheet("扫描记录");

        List<Object[]> operatingList = operatingRepository.getForExcel(beginDate,endDate);

        //新增数据行，并且设置单元格数据

        int rowNum = 1;

        String[] headers = { "设备名称", "设备编号", "NE1资产编号", "使用人", "UAES固定资产编号", "保管人", "所属科室", "扫描日期"};
        //headers表示excel表中第一行的表头

        HSSFRow row = sheet.createRow(0);
        //在excel表中添加表头

        for(int i=0;i<headers.length;i++){
            HSSFCell cell = row.createCell(i);
            HSSFRichTextString text = new HSSFRichTextString(headers[i]);
            cell.setCellValue(text);
        }

        //在表中存放查询到的数据放入对应的列
        for (Object[] operating : operatingList) {
            HSSFRow row1 = sheet.createRow(rowNum);
            row1.createCell(0).setCellValue(operating[0] == null ? "" : operating[0].toString());
            row1.createCell(1).setCellValue(operating[1] == null ? "" : operating[1].toString());
            row1.createCell(2).setCellValue(operating[2] == null ? "" : operating[2].toString());
            row1.createCell(3).setCellValue(operating[3] == null ? "" : operating[3].toString());
            row1.createCell(4).setCellValue(operating[4] == null ? "" : operating[4].toString());
            row1.createCell(5).setCellValue(operating[6] == null ? "" : operating[6].toString());
            row1.createCell(6).setCellValue(operating[5] == null ? "" : operating[5].toString());
            row1.createCell(7).setCellValue(operating[7] == null ? "" : operating[7].toString());
            rowNum++;
        }

        ByteArrayOutputStream os = new ByteArrayOutputStream();
        try
        {
            workbook.write(os);
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

        byte[] content = os.toByteArray();
        File file = new File(path);//Excel文件生成后存储的位置。
        OutputStream fos  = null;
        try
        {
            fos = new FileOutputStream(file);
            fos.write(content);
            os.close();
            fos.close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
}
