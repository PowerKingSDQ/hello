package com.uaes.service;
public class ScheduledTasks {

}
//
//
//import com.uaes.entity.Device;
//import com.uaes.entity.Operating;
//import com.uaes.entity.User;
//import com.uaes.repository.DeviceCusRepository;
//import com.uaes.repository.OperatingRepository;
//import com.uaes.repository.ScanRepository;
//import com.uaes.repository.UserRepository;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.scheduling.annotation.Scheduled;
//import org.springframework.stereotype.Component;
//
//import java.sql.Timestamp;
//import java.text.SimpleDateFormat;
//import java.time.LocalDateTime;
//import java.time.format.DateTimeFormatter;
//import java.time.temporal.ChronoUnit;
//import java.util.Date;
//import java.util.List;
//
//@Component
//public class ScheduledTasks {
//
//    @Autowired
//    private DeviceCusRepository deviceCusRepository;
//    @Autowired
//    private ScanRepository scanRepository;
//    @Autowired
//    private OperatingRepository operatingRepository;
//
//    @Autowired
//    private UserRepository userRepositoty;
//
//    @Autowired
//    private MailService mailService;
//
//    @Value("${defaultCcMailAddr}")
//    String defaultCcMailAddr;
//
//    @Value("${defaultScanPeriodDays}")
//    int defaultScanPeriodDays;
//
//    @Value("${defaultScanPeriodHours}")
//    int defaultScanPeriodHours;
//
//
//    private static final Logger log = LoggerFactory.getLogger(ScheduledTasks.class);
//
//    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
//
//    //    @Scheduled(fixedRate = 300000)   // unit:ms
////    @Scheduled(cron=". . .")    // 0 0 0 * * ?表示每天0点0分执行。
////    @Scheduled(cron="0 * 11 * * ?")     //0 * 22 * * ?表示每天11点开始每分钟
//    @Scheduled(cron = "0 0 0 * * ?")     //* 0 * * * ? 表示每小时0分
//    public void checkScanStatus() {
//        log.info("The time is now {}", dateFormat.format(new Date()));
//
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");LocalDateTime now = LocalDateTime.now();
//
//        //查询所有设备
//        //System.out.print("deviceCusRepository.findAll():" + deviceCusRepository.findAll());
//        //查询所有设备，只查找状态为正常的设备  0.正常  1.报修  2.在修  3.已损坏  4.已归还
//        List<Device> deviceList = deviceCusRepository.findAllByStatus(0);
//        //获取设备数量
//        int deviceListSize = deviceList.size();
//
//        System.out.println("正常设备的总数量为:" + deviceListSize);
//
//        int deviceListIndex = 0;
//
//        for (; deviceListIndex < deviceListSize; deviceListIndex++) {
//
//            List<Operating> operatingList = operatingRepository.findAllByNe1did(deviceList.get(deviceListIndex).getNe1did());
//            if (operatingList.size() <= 0)
//                continue;
//
//            // 获取该设备最近扫描时间（最大时间）
//            int sizeOfOperatingList = operatingList.size();
//            Timestamp maxtimestamp = Timestamp.valueOf("2011-05-09 11:49:45");
//            Timestamp tmptimestamp = Timestamp.valueOf("2011-05-09 11:49:45");
//            int maxtimestampindex = 0;
//            //获取该设备最后一次扫描时间
//            for (int index = 0; index < sizeOfOperatingList; index++) {
//                String opstmap = operatingList.get(index).getTimestamp();
//                tmptimestamp = Timestamp.valueOf(opstmap);
//                if (tmptimestamp.after(maxtimestamp)) {
//                    maxtimestampindex = index;
//                    maxtimestamp = tmptimestamp;
//                }
//            }
//
//            String maxtimestr = sdf.format(maxtimestamp);
//            System.out.println("maxtimestr:" + maxtimestr);
//
//            LocalDateTime last = LocalDateTime.parse(maxtimestr, dtf);
//
//            long daysDiff = ChronoUnit.DAYS.between(last, now);
//            long hoursDiff = ChronoUnit.HOURS.between(last, now);
//
//
//            System.out.println("daysDiff = [" + daysDiff + "]");
//            System.out.println("hoursDiff = [" + hoursDiff + "]");
//
//            //获取此设备科室信息
//            String section = deviceList.get(deviceListIndex).getSection();
//            String userEmailAddr = null;
//            //获取设备当前使用人
//            String owner = deviceList.get(deviceListIndex).getOwner();
//            //获取使用人详细信息
//            List<User> listOwner = userRepositoty.findByEname(owner);
//            //设备只能有一个人使用，所以List里只有一个人
//            if (deviceListSize > 0 && owner != null && listOwner.size() > 0) {
//                userEmailAddr = listOwner.get(0).getEmail();
//            }
//            //获取设备所属科室管理员
//            List<User> sectionAdmin = userRepositoty.findByEsectionAndUgroup(section, "admin");
//            //String sectionAdminEmailAddr;
//            //设备所属科室管理员可能有很多,这些都需要抄送
//            if (sectionAdmin.size() <= 0) {
//                User u = new User();
//                u.setEmail("xia.chen@uaes.com");
//                sectionAdmin.add(0,u);
//            }
//            // over  two weeks
//            //TODO:
//            if (daysDiff > defaultScanPeriodDays && userEmailAddr != null) {
//                sendmail(userEmailAddr,
//                        sectionAdmin,
//                        deviceList.get(deviceListIndex).getDname(),
//                        deviceList.get(deviceListIndex).getNe1did(),
//                        maxtimestr,
//                        daysDiff);
//                System.out.println("发送到：" + userEmailAddr);
//                System.out.println("抄送给：" + sectionAdmin);
//                System.out.println("NE1did：" + deviceList.get(deviceListIndex).getNe1did());
//                //qq 邮箱对每分钟发邮件的数量有限制
//                // ref ： http://service.mail.qq.com/cgi-bin/help?subtype=1&id=20022&no=1000722
//                // 因此，每发一份邮件 ，暂停 30s
//                try {
//                    Thread.sleep(30 * 1000);
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//        }
//    }
//
//
//    public void sendmail(String sendTo, String copyTo, String deviceName, String Ne1Did, String lastScanTime, long daysdiff) {
//
//        LocalDateTime today = LocalDateTime.now();
//        DateTimeFormatter dfyyymmdd = DateTimeFormatter.ofPattern("yyyy-MM-dd");
//
//        String mailContextFormat = "%s:\n\r" +
//                "\n\r" +
//                "\t您好！\n\r" +
//                "\t您正在使用的设备（ 设备名：%s NE1Did:%s） 上一次扫描时间是：%s ,\n\r" +
//                "\t已经超过%d天没有扫描，请尽快扫描。\n\r" +
//                "\n\r" +
//                "\t谢谢！\n\r" +
//                "\n\r" +
//                "NE1设备管理团队\n\r" +
//                "%s\n\r";
//
//        String userName = sendTo.substring(0, sendTo.indexOf("@"));
//
//        String mailContent = String.format(mailContextFormat, userName, deviceName, Ne1Did,
//                lastScanTime, daysdiff,
//                today.format(dfyyymmdd));
//
//        String mailObject = String.format("设备管理提醒邮件（%s）", deviceName);
//
//
//        mailService.sendAndCopySimpleMail(sendTo, copyTo, mailObject, mailContent);
//
//    }
//
//    /**
//     * 抄送的人不只一个的时候
//     * @param sendTo
//     * @param copyTo
//     * @param deviceName
//     * @param Ne1Did
//     * @param lastScanTime
//     * @param daysdiff
//     */
//    public void sendmail(String sendTo, List<User> copyTo, String deviceName, String Ne1Did, String lastScanTime, long daysdiff) {
//
//        LocalDateTime today = LocalDateTime.now();
//        DateTimeFormatter dfyyymmdd = DateTimeFormatter.ofPattern("yyyy-MM-dd");
//
//        String mailContextFormat = "%s:\n\r" +
//                "\n\r" +
//                "\t您好！\n\r" +
//                "\t您正在使用的设备（ 设备名：%s NE1Did:%s） 上一次扫描时间是：%s ,\n\r" +
//                "\t已经超过%d天没有扫描，请尽快扫描。\n\r" +
//                "\n\r" +
//                "\t谢谢！\n\r" +
//                "\n\r" +
//                "NE1设备管理团队\n\r" +
//                "%s\n\r";
//
//        String userName = sendTo.substring(0, sendTo.indexOf("@"));
//
//        String mailContent = String.format(mailContextFormat, userName, deviceName, Ne1Did,
//                lastScanTime, daysdiff,
//                today.format(dfyyymmdd));
//
//        String mailObject = String.format("设备管理提醒邮件（%s）", deviceName);
//        if(copyTo.size() > 0){
//            String [] cc = new String[copyTo.size()];
//            for(int i = 0;i < copyTo.size();i++){
//                cc[i] = copyTo.get(i).getEmail();
//            }
//            mailService.sendAndCopySimpleMail(sendTo, cc, mailObject, mailContent);
//        }
//    }
//}

