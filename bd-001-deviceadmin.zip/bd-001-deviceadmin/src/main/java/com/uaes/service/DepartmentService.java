package com.uaes.service;

import com.uaes.entity.Department;
import org.springframework.data.domain.Page;

import java.util.List;

public interface DepartmentService {

    public void deleteDepartment(String ids);

    public Department getDepartmentById(String id);

    public List<Department> getDepartmentByName(String department);

    Page<Department> findDepartmentCriteria(Integer page, Integer size, Department department);

    public Department saveDepartment(Department department);
}
