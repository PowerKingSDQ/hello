package com.uaes.service.impl;

import com.uaes.entity.User;
import com.uaes.entity.UserQuery;
import com.uaes.service.UserQueryService;
import com.uaes.repository.UserRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

@Service(value = "userQueryService")
public class UserQueryServiceImpl implements UserQueryService {
    @Resource
    UserRepository userRepository;

    @Override
    public User findBySn(Integer sn) {
        return userRepository.findBySn(sn);
    }

    @Override
    public Page<User> findUserCriteria(Integer page, Integer size, UserQuery userQuery) {
        Pageable pageable = new PageRequest(page, size, Sort.Direction.ASC, "sn");
        Page<User> userPage = userRepository.findAll(new Specification<User>() {
            @Override
            public Predicate toPredicate(Root<User> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> list = new ArrayList<Predicate>();
                if (StringUtils.hasLength(userQuery.getEid())) {
                    list.add(cb.like(root.get("eid").as(String.class), "%" + userQuery.getEid() + "%"));
                }
                if (StringUtils.hasLength(userQuery.getEname())) {
                    list.add(cb.like(root.get("ename").as(String.class), "%" + userQuery.getEname() + "%"));
                }
                if (StringUtils.hasLength(userQuery.getEsection())) {
                    list.add(cb.like(root.get("esection").as(String.class), "%" + userQuery.getEsection() + "%"));
                }
                if (StringUtils.hasLength(userQuery.getEmail())) {
                    list.add(cb.like(root.get("email").as(String.class), "%" + userQuery.getEmail() + "%"));
                }
                if (StringUtils.hasLength(userQuery.getWechatid())) {
                    list.add(cb.like(root.get("wechatid").as(String.class), "%" + userQuery.getWechatid() + "%"));
                }
                if (StringUtils.hasLength(userQuery.getPhonenum())) {
                    list.add(cb.like(root.get("phonenum").as(String.class), "%" + userQuery.getPhonenum() + "%"));
                }
                if (StringUtils.hasLength(userQuery.getUgroup())) {
                    list.add(cb.like(root.get("ugroup").as(String.class), "%" + userQuery.getUgroup() + "%"));
                }
                Predicate[] p = new Predicate[list.size()];
                return cb.and(list.toArray(p));
            }
        }, pageable);
        return userPage;
    }
}
