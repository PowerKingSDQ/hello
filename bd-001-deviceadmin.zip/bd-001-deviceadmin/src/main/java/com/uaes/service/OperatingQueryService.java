package com.uaes.service;

import com.uaes.entity.Operating;
import com.uaes.entity.OperatingQuery;
import org.springframework.data.domain.Page;

public interface OperatingQueryService {
    Page<Operating> findOperatingCriteria(Integer page, Integer size, OperatingQuery operatingQuery);
}
