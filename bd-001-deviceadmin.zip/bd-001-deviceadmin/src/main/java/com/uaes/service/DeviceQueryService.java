package com.uaes.service;

import com.uaes.entity.Device;
import com.uaes.entity.DeviceQuery;
import org.springframework.data.domain.Page;

import java.util.List;

public interface DeviceQueryService {
    Page<Device> findDeviceCriteria(Integer page, Integer size, DeviceQuery deviceQuery);

    Device findBySn(Integer sn);

    void edit(Device device);

    List<Device> findByUaesDid(String uaesdid);

    List<Device> getDeviceByParam(String ne1did);

    //List<Device> findByNE1did(String ne1did);
}
