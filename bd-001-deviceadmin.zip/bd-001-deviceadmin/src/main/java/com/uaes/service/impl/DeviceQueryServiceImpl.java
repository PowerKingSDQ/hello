package com.uaes.service.impl;

import com.uaes.entity.Device;
import com.uaes.entity.DeviceQuery;
import com.uaes.service.DeviceQueryService;
import com.uaes.repository.DeviceRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

@Service(value = "deviceQueryService")
public class DeviceQueryServiceImpl implements DeviceQueryService {
    @Resource
    DeviceRepository deviceRepository;

    @Override
    public Page<Device> findDeviceCriteria(Integer page, Integer size, final DeviceQuery deviceQuery) {
        Pageable pageable = new PageRequest(page, size, Sort.Direction.DESC, "firstusedate");
        Page<Device> devicePage = deviceRepository.findAll(new Specification<Device>() {
            @Override
            public Predicate toPredicate(Root<Device> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> list = new ArrayList<Predicate>();
                if (StringUtils.hasLength(deviceQuery.getDname())) {
                    list.add(cb.like(root.get("dname").as(String.class), "%" + deviceQuery.getDname() + "%"));
                }
                if (StringUtils.hasLength(deviceQuery.getCustodian())) {
                    list.add(cb.like(root.get("custodian").as(String.class), "%" + deviceQuery.getCustodian() + "%"));
                }
                if (StringUtils.hasLength(deviceQuery.getUaesdid())) {
                    list.add(cb.like(root.get("uaesdid").as(String.class), "%" + deviceQuery.getUaesdid() + "%"));
                }
                if (StringUtils.hasLength(deviceQuery.getDid())) {
                    list.add(cb.like(root.get("did").as(String.class), "%" + deviceQuery.getDid() + "%"));
                }
                List<String> sections = deviceQuery.getSections();
                if (sections != null && sections.size() > 0) {
                    CriteriaBuilder.In<String> in = cb.in(root.get("section"));
                    for (String section : sections) {
                        in.value(section);
                    }
                    list.add(in);
                }
                if (StringUtils.hasLength(deviceQuery.getEid())) {
                    list.add(cb.like(root.get("eid").as(String.class), "%" + deviceQuery.getEid() + "%"));
                }
                List<String> status = deviceQuery.getStatus();
                if (status != null && status.size() > 0) {
                    CriteriaBuilder.In<String> in = cb.in(root.get("status"));
                    for (String s : status) {
                        in.value(s);
                    }
                    list.add(in);
                }
//                if (StringUtils.hasLength(deviceQuery.getStatus())) {
//                    list.add(cb.like(root.get("status").as(String.class), "%" + deviceQuery.getStatus() + "%"));
//                }
                if (StringUtils.hasLength(deviceQuery.getNe1did())) {
                    list.add(cb.like(root.get("ne1did").as(String.class), "%" + deviceQuery.getNe1did() + "%"));
                }
                if (StringUtils.hasLength(deviceQuery.getOwner())) {
                    list.add(cb.like(root.get("owner").as(String.class), "%" + deviceQuery.getOwner() + "%"));
                }
                if (StringUtils.hasLength(deviceQuery.getRemarks())) {
                    list.add(cb.like(root.get("remarks").as(String.class), "%" + deviceQuery.getRemarks() + "%"));
                }
                Predicate[] p = new Predicate[list.size()];
                return cb.and(list.toArray(p));
            }
        }, pageable);
        return devicePage;
    }

    @Override
    public Device findBySn(Integer sn) {
        return deviceRepository.findBySn(sn);
    }

    @Override
    public void edit(Device device) {
        deviceRepository.save(device);
    }

    @Override
    public List<Device> findByUaesDid(String uaesDid) {
        return deviceRepository.findByUaesDid(uaesDid);
    }

    @Override
    public List<Device> getDeviceByParam(String ne1did) {
        return deviceRepository.getDeviceByParam(ne1did);
    }

//    @Override
//    public List<Device> findByNE1did(String ne1did) {
//        return deviceRepository.findByNE1did(ne1did);
//    }
}
