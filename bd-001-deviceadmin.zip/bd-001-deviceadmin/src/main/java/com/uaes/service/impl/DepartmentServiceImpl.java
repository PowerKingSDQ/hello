package com.uaes.service.impl;

import com.uaes.entity.Department;
import com.uaes.entity.Device;
import com.uaes.repository.DepartmentRespository;
import com.uaes.service.DepartmentService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import javax.annotation.Resources;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

@Service(value = "departmentService")
public class DepartmentServiceImpl implements DepartmentService{

    @Resource
    DepartmentRespository departmentRespository;

    @Override
    public void deleteDepartment(String ids) {
        departmentRespository.deleteDepartment(ids);
    }

    @Override
    public Department getDepartmentById(String id) {
        return departmentRespository.getDepartmentById(id);
    }

    @Override
    public List<Department> getDepartmentByName(String department) {
        return departmentRespository.getDepartmentByName(department);
    }

    @Override
    public Page<Department> findDepartmentCriteria(Integer page, Integer size, Department department) {
        Pageable pageable = new PageRequest(page, size, Sort.Direction.ASC, "id");
        Page<Department> departmentPage = departmentRespository.findAll(new Specification<Department>() {
            @Override
            public Predicate toPredicate(Root<Department> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> list = new ArrayList<Predicate>();
                list.add(cb.equal(root.get("isdelted").as(String.class), "0"));
                if (StringUtils.hasLength(department.getDepartment())) {
                    list.add(cb.like(root.get("department").as(String.class), "%" + department.getDepartment() + "%"));
                }
                Predicate[] p = new Predicate[list.size()];
                return cb.and(list.toArray(p));
            }
        }, pageable);
        return departmentPage;
    }

    @Override
    public Department saveDepartment(Department department) {
        return departmentRespository.save(department);
    }
}
