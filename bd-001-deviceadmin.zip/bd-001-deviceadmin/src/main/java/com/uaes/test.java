package com.uaes;

import java.text.DateFormat;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class test {

    public static void main(String [] args){
        DateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
        ParsePosition pos = new ParsePosition(0);
        ParsePosition pos1 = new ParsePosition(0);
        Date firstDate = format1.parse("2018-10-11",pos);
        Date secondDate = format1.parse("2019-01-11",pos1);
        Calendar firstCal = Calendar.getInstance();
        Calendar secondCal = Calendar.getInstance();
        firstCal.setTime(firstDate);
        secondCal.setTime(secondDate);
        int day1= firstCal.get(Calendar.DAY_OF_YEAR);
        int day2 = secondCal.get(Calendar.DAY_OF_YEAR);
        int year1 = firstCal.get(Calendar.YEAR);
        int year2 = secondCal.get(Calendar.YEAR);
        if(year1 != year2){
            int timeDistance = 0 ;
            for(int i = year1 ; i < year2 ; i ++)
            {
                if(i%4==0 && i%100!=0 || i%400==0)    //闰年
                {
                    timeDistance += 366;
                }
                else    //不是闰年
                {
                    timeDistance += 365;
                }
            }
            System.out.println(timeDistance + (day2-day1));
        }else {
            System.out.println("判断day2 - day1 : " + (day2-day1));
        }
    }
}
