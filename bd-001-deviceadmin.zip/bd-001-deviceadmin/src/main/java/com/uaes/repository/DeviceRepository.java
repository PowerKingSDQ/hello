package com.uaes.repository;

import com.uaes.entity.Device;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("deviceRepository")
public interface DeviceRepository extends JpaRepository<Device, Long>
        , JpaSpecificationExecutor<Device> {
    Device findBySn(Integer sn);

    @Query(value = "select * from device where uaesdid=?1 order by firstusedate",nativeQuery = true)
    List<Device> findByUaesDid(String uaesdid);

    @Query(value = "select * from device where ne1did=?1 order by firstusedate",nativeQuery = true)
    List<Device> getDeviceByParam(String ne1did);

//    @Query(value = "select * from device where ne1did=?1",nativeQuery = true)
//    List<Device> findByNE1did(String ne1did);
}
