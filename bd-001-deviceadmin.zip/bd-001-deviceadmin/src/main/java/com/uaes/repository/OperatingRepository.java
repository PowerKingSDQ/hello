package com.uaes.repository;

import com.uaes.entity.Operating;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OperatingRepository extends CrudRepository<Operating, Long>, JpaRepository<Operating, Long>
        , JpaSpecificationExecutor<Operating> {
    List<SnNe1didScannerDescription> findSnNe1didScannerDescriptionBy();

    List<Operating> findAllBy();

    List<Operating> findAllByNe1did(String ne1did);

    Operating findBySn(Integer sn);

    @Query(value = "SELECT d.dname dname, d.uaesdid uaesdid, n.ne1did ne1did, n.scanner owner, n.timestamp timestamp "+
            "FROM operating n left join device d on n.ne1did = d.ne1did " +
            "where (dname like concat(:dname1,'%') or dname like concat(:dname2,'%') or dname like concat(:dname3,'%')) " +
            "and d.section = :section " +
            "order by timestamp asc",nativeQuery = true)
    List<Object[]> findAllByDateAndName(@Param("dname1") String dname1, @Param("dname2") String dname2,@Param("dname3") String dname3,@Param("section") String section);

    @Query(value = "SELECT max(d.dname) dname, max(d.uaesdid) uaesdid, max(n.ne1did) ne1did, max(n.scanner) owner, max(n.timestamp) timestamp "+
            "FROM operating n left join device d on n.ne1did = d.ne1did " +
            "where (dname like concat(:dname1,'%') or dname like concat(:dname2,'%') or dname like concat(:dname3,'%')) " +
            "and d.section = :section " +
            "group by n.ne1did order by timestamp asc",nativeQuery = true)
    List<Object[]> findAllDistictByDateAndName(@Param("dname1") String dname1, @Param("dname2") String dname2,@Param("dname3") String dname3,@Param("section") String section);

    //    @Query(value = "SELECT t.* ,MAX(t.timestamp) FROM (SELECT o.* ,p.esection FROM operating o " +
//            "LEFT JOIN (SELECT u.ename,u.esection FROM `user` u GROUP BY u.ename) p ON o.scanner=p.ename)t " +
//            "where t.ne1did like concat('%',:ne1did,'%') and t.scanner like concat('%',:scanner,'%') " +
//            "and (t.timestamp between :beginTime and :endTime) GROUP BY t.scanner order by MAX(t.timestamp) desc /* #pageable */",
//            countQuery = "select count(*) from (SELECT t.* ,MAX(t.timestamp) FROM (SELECT o.* ,p.esection FROM operating o " +
//                    "LEFT JOIN (SELECT u.ename,u.esection FROM `user` u GROUP BY u.ename) p ON o.scanner=p.ename)t " +
//                    "where t.ne1did like concat('%',:ne1did,'%') and t.scanner like concat('%',:scanner,'%') " +
//                    "and (t.timestamp between :beginTime and :endTime) GROUP BY t.scanner " +
//                    "order by MAX(t.timestamp) desc /* #pageable */) m", nativeQuery = true)
    @Query(value = "SELECT max(d.dname) dname,max(d.did) did,n.ne1did ne1did,max(d.owner) owner,max(d.status) status,max(d.uaesdid) uaesdid, "+
            "max(d.section) section,max(d.custodian) custodian,max(d.description) description,max(n.timestamp) timestamp "+
            "FROM operating n left join device d on n.ne1did = d.ne1did " +
            "where dname like concat('%',:dname,'%') and did like concat('%',:did,'%') and d.ne1did like concat('%',:ne1did,'%') " +
            "and owner like concat('%',:owner,'%') and uaesdid like concat('%',:uaesdid,'%') and custodian like concat('%',:custodian,'%') "+
            "and d.description like concat('%',:description,'%') and (timestamp between :beginTime and :endTime) " +
            "and d.status in (:status) and d.section in (:section) "+
            "group by n.ne1did order by timestamp desc /* #pageable */",
            countQuery = "select count(1) from (SELECT n.ne1did,max(n.timestamp) timestamp " +
                    "FROM operating n left join device d on n.ne1did = d.ne1did " +
                    "where dname like concat('%',:dname,'%') and did like concat('%',:did,'%') and d.ne1did like concat('%',:ne1did,'%') " +
                    "and owner like concat('%',:owner,'%') and uaesdid like concat('%',:uaesdid,'%') and custodian like concat('%',:custodian,'%') "+
                    "and d.description like concat('%',:description,'%') and (timestamp between :beginTime and :endTime) " +
                    "and d.status in (:status) and d.section in (:section) "+
                    "group by n.ne1did ) b /* #pageable */", nativeQuery = true)
    Page<Object[]> findConditions(@Param("dname") String dname,@Param("did") String did,
                                  @Param("ne1did") String ne1did, @Param("owner") String owner,@Param("status") String [] status,
                                  @Param("custodian") String custodian,@Param("section") String [] section,
                                  @Param("description") String description, @Param("uaesdid") String uaesdid,
                                  @Param("beginTime") String beginTime, @Param("endTime") String endTime, Pageable pageable);

    @Query(value = "SELECT max(d.dname) dname,max(d.did) did,n.ne1did ne1did,max(d.owner) owner,max(d.uaesdid) uaesdid, "+
            "max(d.section) section,max(d.custodian) custodian,max(n.timestamp) timestamp "+
            "FROM operating n left join device d on n.ne1did = d.ne1did " +
            "where (timestamp between :beginTime and :endTime) and d.section = 'ESW' " +
            "group by n.ne1did order by timestamp desc",nativeQuery = true)
    List<Object[]> getForExcel(@Param("beginTime") String beginTime, @Param("endTime") String endTime);
}
