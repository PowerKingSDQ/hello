package com.uaes.repository;

import com.uaes.entity.Device;
import com.uaes.entity.DeviceQuery;
import org.springframework.data.domain.Page;

public interface DeviceQueryService {
    Page<Device> findDeviceCriteria(Integer page, Integer size, DeviceQuery deviceQuery);

    Device findBySn(Integer sn);

    void edit(Device device);
}
