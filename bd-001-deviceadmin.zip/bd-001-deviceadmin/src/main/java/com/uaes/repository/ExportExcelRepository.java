package com.uaes.repository;

import com.uaes.entity.ExportExcel;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface ExportExcelRepository extends CrudRepository<ExportExcel, Long> {

    @Query(value = "select * from exportexcel where timelimit = ?1 and status = 0",nativeQuery = true)
    public List<ExportExcel> getDataForExport(String timelimit);

}
