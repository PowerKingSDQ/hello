package com.uaes.repository;

public interface DnameAndDid {
    String getDname();

    String getNe1did();

    String getStatus();

    String getDescription();

    String getDpic();

    String getUaesdid();

    String getPrcodepath();
}
