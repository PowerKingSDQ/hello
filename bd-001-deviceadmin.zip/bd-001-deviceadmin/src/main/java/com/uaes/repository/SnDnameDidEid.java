package com.uaes.repository;

public interface SnDnameDidEid{
    String getSn();
    String getDname();
    String getDid();
    String getEid();
    String getName();
    String getPrcodepath();
    String getNe1did();
    String getUaesdid();
    String getOwner();
    String getFirstusedate();
    String getStatus();
    String getsection();
}
