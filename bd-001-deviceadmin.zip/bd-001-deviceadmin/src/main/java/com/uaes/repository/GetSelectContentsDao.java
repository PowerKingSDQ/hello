package com.uaes.repository;

import java.util.List;

/**
 * @author xu wen feng 8/9/2018 09:15
 */
public interface GetSelectContentsDao {
    /**
     * 获取下拉部门
     *
     * @return list
     */
    List<String> getSections();

    /**
     * 获取下拉设备状态
     *
     * @return list
     */
    List<String> getDeviceStatus();
}
