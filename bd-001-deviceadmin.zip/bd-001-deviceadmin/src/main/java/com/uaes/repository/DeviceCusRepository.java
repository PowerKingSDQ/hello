package com.uaes.repository;

import com.uaes.entity.Device;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

// This will be AUTO IMPLEMENTED by Spring into a Bean called userRepository
// CRUD refers Create, Read, Update, Delete

public interface DeviceCusRepository extends CrudRepository<Device, Long> {
    List<Device> findByDid(String did);

    List<DnameAndDid> findByEid(String eid);

    List<DnameAndDid> findByName(String name);

    List<DnameAndDid> findByOwner(String owner);

    List<SnDnameDidEid> findSnDnameDidEidBy();

    List<Device> findAllBy();
    @Query(value = "select * from device d where d.status = ?1",nativeQuery = true)
    List<Device> findAllByStatus(int status);

    List<Device> findByNe1did(String ne1did);

    Page<SnDnameDidEid> findAll(Pageable pageable);
    List<Device> findByNe1didLikeOrNameLikeOrDnameLikeOrSectionLike(String ne1did, String name, String dname, String section);
   
    @Transactional
    @Modifying
    @Query("update Device d set d.name = ?3,d.owner = ?2 where d.ne1did = ?1")
    int setDeviceUser(String ne1did, String scaner, String name);

    @Transactional
    @Modifying
    @Query("update Device d set d.status = ?2 where d.ne1did = ?1")
    int setDeviceStatus(String ne1did, String status);

    @Transactional
    void deleteBySn(int id);

    @Query(value = "select * from device d where " +
            "dname like concat('%',:dname,'%') or section like concat('%',:section,'%') or d.ne1did like concat('%',:ne1did,'%') " +
            "or d.name like concat('%',:name,'%') order by firstusedate desc /* #pageable */",
            countQuery = "select count(1) from device d where " +
                    "dname like concat('%',:dname,'%') or section like concat('%',:section,'%') or d.ne1did like concat('%',:ne1did,'%') " +
                    "or d.name like concat('%',:name,'%') order by firstusedate desc /* #pageable */",nativeQuery = true)
    Page<Object[]> getAllDeviceForWX(@Param("dname") String dname, @Param("ne1did") String ne1did,
                                     @Param("section") String section, @Param("name")String name, Pageable pageable);

}
