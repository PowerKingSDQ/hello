package com.uaes.repository;

import com.uaes.entity.PrintQRcode;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface PrintQRcodeRepository extends CrudRepository<PrintQRcode, Long>, JpaRepository<PrintQRcode, Long>
        , JpaSpecificationExecutor<PrintQRcode> {
    Page<PrintQRcode> findByPrintstatus(Pageable pageable);

    @Transactional
    @Modifying
    @Query(value = "update printqrcode p set p.printstatus = ?3,p.printtime= ?1 where p.id = ?2",nativeQuery = true)
    int updatePrintQRcodeStatus(String printTime, String id, int status);
    List<PrintQRcode> findByDevicenameLikeOrUaesdidLikeOrRegisteruserLike(String devicename, String uaesdid, String registerUser);
    @Query(value = "select * from  printqrcode p where p.devicename= ?1 and p.ne1did = ?2 and p.registeruser = ?3",nativeQuery = true)
    List<PrintQRcode> findPrintByParam(String devicename, String ne1did, String registerUser);
    @Query(value = "select * from printqrcode d where " +
            "(devicename like concat('%',:dname,'%') or uaesdid like concat('%',:uaesdid,'%') " +
            "or d.registeruser like concat('%',:registeruser,'%')) and printstatus = 0 order by registertime desc /* #pageable */",
            countQuery = "select count(1) from printqrcode d where " +
            "(devicename like concat('%',:dname,'%') or uaesdid like concat('%',:uaesdid,'%') " +
            "or d.registeruser like concat('%',:registeruser,'%')) and printstatus = 0 order by registertime desc /* #pageable */",nativeQuery = true)
    Page<Object[]> getAllPrintQDForWX(@Param("dname") String dname, @Param("uaesdid") String ne1did,
                                     @Param("registeruser") String section, Pageable pageable);
}
