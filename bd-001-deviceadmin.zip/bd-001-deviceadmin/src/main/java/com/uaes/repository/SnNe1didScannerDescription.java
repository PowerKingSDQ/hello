package com.uaes.repository;

public interface SnNe1didScannerDescription {
    String getSn();

    String getNe1did();

    String getScanner();

    String getDescription();
}
