package com.uaes.repository;


// This will be AUTO IMPLEMENTED by Spring into a Bean called userRepository
// CRUD refers Create, Read, Update, Delete

import com.uaes.entity.Operating;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import javax.transaction.Transactional;

public interface ScanRepository extends CrudRepository<Operating, Long> {

    @Transactional
    @Modifying
    @Query("update Operating op set op.operatingtype = ?1 ,op.description = ?2 where op.ne1did = ?3")
    int setOperating(String type, String dec, String ne1did);
}
