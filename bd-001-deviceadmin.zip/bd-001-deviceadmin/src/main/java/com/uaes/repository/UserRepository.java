package com.uaes.repository;

import com.uaes.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface UserRepository extends CrudRepository<User, Long>, JpaRepository<User, Long>
        , JpaSpecificationExecutor<User> {

    List<User> findByEid(String eID);

    List<User> findAllBy();

    List<User> findByEsectionAndUgroup(String eSection, String uGroup);

    List<User> findByEname(String eName);

    List<SnEidEnameEsection> findSnEidEnameEsectionBy();

    List<User> findByEnameLikeAndUgroup(String Ename, String Ugroup);

    List<User> findByUgroup(String Ugroup);

    //    List<User> findByEidAndNickName(String eID,String nickName);
    @Transactional
    @Modifying
    @Query("update User user set user.ugroup = ?2 where user.ename = ?1")
    int setAdmin(String ename, String admin);

    @Transactional
    @Modifying
    @Query("update User user set user.ugroup = ?2 where user.sn = ?1")
    int updateAdmin(int sn, String user);

    User findBySn(Integer sn);
}
