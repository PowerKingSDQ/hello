package com.uaes.repository;

import com.uaes.entity.User;
import com.uaes.entity.UserQuery;
import org.springframework.data.domain.Page;

public interface UserQueryService {
    Page<User> findUserCriteria(Integer page, Integer size, UserQuery userQuery);

    User findBySn(Integer sn);
}
