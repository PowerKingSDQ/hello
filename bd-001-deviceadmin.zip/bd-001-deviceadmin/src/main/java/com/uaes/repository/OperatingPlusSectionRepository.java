package com.uaes.repository;

import com.uaes.entity.OperatingPlusSection;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 * @author xu wen feng 8/13/2018 14:22
 */
public interface OperatingPlusSectionRepository extends JpaRepository<OperatingPlusSection, Long>
        , JpaSpecificationExecutor<OperatingPlusSection> {

    @Query(value = "SELECT s.* FROM (SELECT o.* ,p.section FROM operating o LEFT JOIN (SELECT d.owner,d.section section FROM device d GROUP BY d.owner)p ON o.scanner = p.owner)s where s.section like CONCAT('%',:section,'%') AND s.ne1did like CONCAT('%',:ne1did,'%') AND s.scanner like CONCAT('%',:scanner,'%') AND (s.timestamp between :beginTime and :endTime) ORDER BY ?#{#pageable}",
            countQuery = "SELECT COUNT(*) FROM (SELECT s.* FROM (SELECT o.* ,p.section FROM operating o LEFT JOIN (SELECT d.owner,d.section section FROM device d GROUP BY d.owner)p ON o.scanner = p.owner)s)t",

            nativeQuery = true)
    Page<OperatingPlusSection> findLike(Pageable pageable, @Param("section") String section, @Param("ne1did") String ne1did, @Param("beginTime") String beginTime, @Param("endTime") String endTime, @Param("scanner") String scanner);

}
