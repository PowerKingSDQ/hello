package com.uaes.repository.impl;

import com.uaes.repository.GetSelectContentsDao;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

/**
 * @author xu wen feng 8/9/2018 09:18
 */
@Repository
public class GetSelectContentsDaoImpl implements GetSelectContentsDao {
    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public List<String> getSections() {
        Query query = entityManager.createQuery("Select distinct department from Department");
        return query.getResultList();
    }

    @Override
    public List<String> getDeviceStatus() {
        Query query = entityManager.createQuery("Select distinct status from Device");
        return query.getResultList();
    }
}
