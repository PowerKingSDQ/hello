package com.uaes.repository;

public interface SnEidEnameEsection {
    String getSn();

    String getEid();

    String getEname();

    String getEsection();
}
