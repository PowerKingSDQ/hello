package com.uaes.repository;

import com.uaes.entity.Department;
import org.hibernate.annotations.SQLUpdate;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface DepartmentRespository extends CrudRepository<Department, Long>,JpaSpecificationExecutor<Department> {

    @Transactional
    @Modifying
    @Query(value = "update department set isdelted = 1 where id = ?1",nativeQuery = true)
    public void deleteDepartment(String id);

    @Query(value = "select * from department where id = ?1",nativeQuery = true)
    public Department getDepartmentById(String id);

    @Query(value = "select * from department where department = ?1",nativeQuery = true)
    public List<Department> getDepartmentByName(String department);
}
