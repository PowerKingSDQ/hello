package com.uaes.configuration;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

@Configuration
public class MyWebAppConfigurer extends WebMvcConfigurerAdapter implements ApplicationContextAware {
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/static/**").addResourceLocations("file:/opt/devicesinfo/qrcode/","file:/opt/devicesinfo/deviceImg/","file:/opt/devicesinfo/","classpath:/static/");
        super.addResourceHandlers(registry);
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {

    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        //拦截规则：除了对外接口和登录操作
        registry.addInterceptor(new MyInterceptor()).
                addPathPatterns("/**").
                excludePathPatterns("/user/index").
                excludePathPatterns("/eswmp/*").
                excludePathPatterns("/login");
        super.addInterceptors(registry);
    }
}
