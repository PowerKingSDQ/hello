package com.uaes.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity // This tells Hibernate to make a table out of this class
public class Device {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer sn;
    private String dname;
    private String did;
    private String ne1did;
    private String uaesdid;
    private String owner;
    private String firstusedate;
    /**
     * 状态 0.正常  1.报修  2.在修  3.已损坏  4.已归还
     */
    private String status;
    private String eid;
    private String name;
    private String prcodepath;
    private String description;
    private String dpic;
    private String custodian;
    private String section;
    private String remarks;


    public String getCustodian() {
        return custodian;
    }

    public void setCustodian(String custodian) {
        this.custodian = custodian;
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDpic() {
        return dpic;
    }

    public void setDpic(String dpic) {
        this.dpic = dpic;
    }

    public String getPrcodepath() {
        return prcodepath;
    }

    public void setPrcodepath(String prcodepath) {
        this.prcodepath = prcodepath;
    }

    public String getEid() {

        return eid;
    }

    public void setEid(String eid) {
        this.eid = eid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getSn() {
        return sn;
    }

    public void setSn(Integer sn) {
        this.sn = sn;
    }

    public String getDname() {
        return dname;
    }

    public void setDname(String dname) {
        this.dname = dname;
    }

    public String getDid() {
        return did;
    }

    public void setDid(String did) {
        this.did = did;
    }

    public String getNe1did() {
//        ne1did = ne1did.substring(3);
        return ne1did;
    }

    public void setNe1did(String ne1did) {
        this.ne1did = ne1did;
    }

    public String getUaesdid() {
        return uaesdid;
    }

    public void setUaesdid(String uaesdid) {
        this.uaesdid = uaesdid;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getFirstusedate() {
        return firstusedate;
    }

    public void setFirstusedate(String firstusedate) {
        this.firstusedate = firstusedate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}

