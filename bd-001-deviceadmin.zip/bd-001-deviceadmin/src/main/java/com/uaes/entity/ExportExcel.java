package com.uaes.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * 待发送excel文件表
 */
@Entity(name="exportexcel")
public class ExportExcel {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    private String path;
    /**
     * 0.待发送  1.已发送
     */
    private int status;
    private String createtime;
    private String updatetime;
    /**
     * 时间范围 例:2018-09-21至2018-09-28
     */
    private String timelimit;

    public String getTimelimit() {
        return timelimit;
    }

    public void setTimelimit(String timelimit) {
        this.timelimit = timelimit;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public String getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(String updatetime) {
        this.updatetime = updatetime;
    }
}
