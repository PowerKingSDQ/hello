package com.uaes.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity // This tells Hibernate to make a table out of this class
public class Operating {
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private int sn;
    private String ne1did;
    private String scanner;
    private String operatingtype;
    private String description;
    private String timestamp;
    private String section;

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    public String getOperatingtype() {
        return operatingtype;
    }

    public void setOperatingtype(String operatingtype) {
        this.operatingtype = operatingtype;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getSn() {
        return sn;
    }

    public void setSn(int sn) {
        this.sn = sn;
    }

    public String getNe1did() {
        return ne1did;
    }

    public void setNe1did(String ne1did) {
        this.ne1did = ne1did;
    }

    public String getScanner() {
        return scanner;
    }

    public void setScanner(String scanner) {
        this.scanner = scanner;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
}

