package com.uaes.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OperatingQuery {
    private String ne1did;
    private String scanner;
    private String operatingtype;
    private String description;
    private String timestamp;
    private String beginTime;
    private String endTime;

    public String getNe1did() {
        return ne1did;
    }

    public void setNe1did(String ne1did) {
        this.ne1did = ne1did;
    }

    public String getScanner() {
        return scanner;
    }

    public void setScanner(String scanner) {
        this.scanner = scanner;
    }

    public String getOperatingtype() {
        return operatingtype;
    }

    public void setOperatingtype(String operatingtype) {
        this.operatingtype = operatingtype;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getBeginTime() {
        return beginTime;
    }

    public void setBeginTime(String beginTime) {
        this.beginTime = beginTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }
}
