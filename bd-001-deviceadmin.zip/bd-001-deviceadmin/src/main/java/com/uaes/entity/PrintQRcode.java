package com.uaes.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *  申请打印二维码表
 */
@Entity(name = "printqrcode")
public class PrintQRcode {

    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    private int id;
    /**
     * 设备名称
     */
    private String devicename;
    /**
     * 固定资产编号
     */
    private String uaesdid;
    /**
     * ne1编号
     */
    private String ne1did;
    /**
     *  二维码路径
     */
    private String qrcodepath;
    /**
     *  申请人id
     */
    private String registeruser;
    /**
     *  申请时间
     */
    private String registertime;
    /**
     *  打印时间
     */
    private String printtime;
    /**
     *  打印状态 0.未打印  1.已打印
     */
    private int printstatus;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUaesdid() {
        return uaesdid;
    }

    public void setUaesdid(String uaesdid) {
        this.uaesdid = uaesdid;
    }

    public String getNe1did() {
        return ne1did;
    }

    public void setNe1did(String ne1did) {
        this.ne1did = ne1did;
    }

    public String getQrcodepath() {
        return qrcodepath;
    }

    public void setQrcodepath(String qrcodepath) {
        this.qrcodepath = qrcodepath;
    }

    public String getRegistertime() {
        return registertime;
    }

    public void setRegistertime(String registertime) {
        this.registertime = registertime;
    }

    public String getPrinttime() {
        return printtime;
    }

    public void setPrinttime(String printtime) {
        this.printtime = printtime;
    }

    public int getPrintstatus() {
        return printstatus;
    }

    public void setPrintstatus(int printttatus) {
        this.printstatus = printttatus;
    }

    public String getRegisteruser() {
        return registeruser;
    }

    public void setRegisteruser(String registeruser) {
        this.registeruser = registeruser;
    }

    public String getDevicename() {
        return devicename;
    }

    public void setDevicename(String devicename) {
        this.devicename = devicename;
    }
}
