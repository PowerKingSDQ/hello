package com.uaes.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * @author xu wen feng 8/13/2018 14:21
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Entity
public class OperatingPlusSection {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int sn;
    private String ne1did;
    private String scanner;
    private String operatingtype;
    private String description;
    private String timestamp;
    private String section;
}
