package com.uaes.entity;

/**
 * 设备转手率统计vo类
 */
public class DeviceTurnoverRateVo {

    private String deviceName;
    private String uaesdid;
    private String ne1did;
    private String owner;
    private String ownDate;
    /*
    转手次数
     */
    private String turnNum;
    /*
    转手率
     */
    private String turnRate;

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public String getUaesdid() {
        return uaesdid;
    }

    public void setUaesdid(String uaesdid) {
        this.uaesdid = uaesdid;
    }

    public String getNe1did() {
        return ne1did;
    }

    public void setNe1did(String ne1did) {
        this.ne1did = ne1did;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getOwnDate() {
        return ownDate;
    }

    public void setOwnDate(String ownDate) {
        this.ownDate = ownDate;
    }

    public String getTurnNum() {
        return turnNum;
    }

    public void setTurnNum(String turnNum) {
        this.turnNum = turnNum;
    }

    public String getTurnRate() {
        return turnRate;
    }

    public void setTurnRate(String turnRate) {
        this.turnRate = turnRate;
    }
}
