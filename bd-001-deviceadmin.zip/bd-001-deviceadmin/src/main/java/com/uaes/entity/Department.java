package com.uaes.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * 科室维护表
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
public class Department {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
    /**
     * 科室
     */
    private String department;
    private String createtime;
    private String creator;
    /**
     * 是否删除   0.未删除  1.已删除
     */
    private int isdelted;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public int getIsdelted() {
        return isdelted;
    }

    public void setIsdelted(int isdelted) {
        this.isdelted = isdelted;
    }

//    @Override
//    public boolean equals(Object o) {
//        //if (this == o) return true;
//        if (o == null || getClass() != o.getClass()) return false;
//        if (!super.equals(o)) return false;
//
//        Department that = (Department) o;
//
//        if (getIsdelted() != that.getIsdelted()) return false;
//        if (!getId().equals(that.getId())) return false;
//        if (!getDepartment().equals(that.getDepartment())) return false;
//        if (!getCreatetime().equals(that.getCreatetime())) return false;
//        return getCreator().equals(that.getCreator());
//    }

//    @Override
//    public int hashCode() {
//        int result = super.hashCode();
//        result = 31 * result + getId().hashCode();
//        result = 31 * result + getDepartment().hashCode();
//        result = 31 * result + getCreatetime().hashCode();
//        result = 31 * result + getCreator().hashCode();
//        result = 31 * result + getIsdelted();
//        return result;
//    }

    @Override
    public String toString() {
        return "Department{" +
                "id=" + id +
                ", departments='" + department + '\'' +
                ", createtime='" + createtime + '\'' +
                ", creator='" + creator + '\'' +
                ", isdelted=" + isdelted +
                '}';
    }
}
