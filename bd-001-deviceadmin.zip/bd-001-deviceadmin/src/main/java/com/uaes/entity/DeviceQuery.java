package com.uaes.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DeviceQuery {
    private String did;
    private String dname;
    private String firstusedate;
    private String ne1did;
    private String owner;
    private List<String> status;
    private String uaesdid;
    private String eid;
    private String prcodepath;
    private String name;
    private String description;
    private String dpic;
    private List<String> sections;
    private String custodian;
    private String remarks;

    public String getDid() {
        return did;
    }

    public void setDid(String did) {
        this.did = did;
    }

    public String getDname() {
        return dname;
    }

    public void setDname(String dname) {
        this.dname = dname;
    }

    public String getFirstusedate() {
        return firstusedate;
    }

    public void setFirstusedate(String firstusedate) {
        this.firstusedate = firstusedate;
    }

    public String getNe1did() {
        return ne1did;
    }

    public void setNe1did(String ne1did) {
        this.ne1did = ne1did;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public List<String> getStatus() {
        return status;
    }

    public void setStatus(List<String> status) {
        this.status = status;
    }

    public List<String> getSections() {
        return sections;
    }

    public void setSections(List<String> sections) {
        this.sections = sections;
    }

    public String getUaesdid() {
        return uaesdid;
    }

    public void setUaesdid(String uaesdid) {
        this.uaesdid = uaesdid;
    }

    public String getEid() {
        return eid;
    }

    public void setEid(String eid) {
        this.eid = eid;
    }

    public String getPrcodepath() {
        return prcodepath;
    }

    public void setPrcodepath(String prcodepath) {
        this.prcodepath = prcodepath;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDpic() {
        return dpic;
    }

    public void setDpic(String dpic) {
        this.dpic = dpic;
    }

    public String getCustodian() {
        return custodian;
    }

    public void setCustodian(String custodian) {
        this.custodian = custodian;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
}
